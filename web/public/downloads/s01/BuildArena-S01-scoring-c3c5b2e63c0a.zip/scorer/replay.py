"""Replay whitelisted operations with hash-pinned official S01 v2.0.1 code."""
import contextlib
import hashlib
import io
import json
from pathlib import Path
import sys
from collections import Counter
import csv
import re
import tomllib
import xml.etree.ElementTree as ET
import inspect
import os

from .evidence import Submission
from .compliance import compare_structure, package_hash
from .artifacts import history_candidates, raw_candidates

ALLOWED = {"start", "attach_block_to", "connect_blocks", "remove_block", "twist_block", "shift_block", "flip_spin"}


def replay_registry(source, dest):
    """Restore authoring availability only for known vanilla types used by S01.

    The local newer catalog disables these entries, although their original
    game meshes/geometry remain present. No geometry or physics is modified.
    """
    path = source / "blocks/block_registry.generated.toml"
    text = path.read_text(encoding="utf-8")
    authoring = tomllib.loads((source / "blocks/block_authoring.toml").read_text(encoding="utf-8"))["by_id"]
    allowed = {key: v["block_name"] for key,v in authoring.items()
               if v["block_name"] in {"Timer", "Logic Gate", "Anglometer", "Speedometer", "Parachute"}}
    before = tomllib.loads(text)
    enabled = []
    for key, name in allowed.items():
        if before["runtime_defs"][key].get("enabled") is False:
            pattern = rf"(\[runtime_defs\.{key}\]\s*\n)enabled = false"
            text, count = re.subn(pattern, r"\1enabled = true", text)
            if count != 1:
                raise ValueError("unexpected registry schema for " + name)
            enabled.append({"id": key, "name": name})
    if before["blocks"]["Parachute"].get("enabled") is False:
        text, count = re.subn(r"(\[blocks\.Parachute\]\s*\n)enabled = false", r"\1enabled = true", text)
        if count != 1:
            raise ValueError("unexpected Parachute registry schema")
        enabled.append({"name": "Parachute", "section": "blocks"})
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(text, encoding="utf-8", newline="\n")
    return {"source_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "adapter_sha256": hashlib.sha256(dest.read_bytes()).hexdigest(), "enabled_vanilla_authoring_entries": enabled,
            "scope": "availability flags only; original game meshes, attachment geometry, parameters and physics unchanged"}


def replay_history(sub, source, history, registry_path=None):
    if not history or history[0].get("op") != "start":
        raise ValueError("plain history starting with start required")
    if any(op.get("op") not in ALLOWED for op in history):
        raise ValueError("unsupported authoring operation; no submitted code executes")
    if sum(op["op"] == "start" for op in history) != 1:
        raise ValueError("multiple start operations require review")
    from buildarena.build import Machine
    with contextlib.chdir(source), contextlib.redirect_stdout(io.StringIO()):
        machine = Machine(name="s01_offline_replay", save_dir=str(sub.path.resolve()), write_full_history=False, registry_path=registry_path)
        for i, op in enumerate(history):
            before = len(machine.operation_history_full)
            machine.operations[op["op"]](**op["params"])
            failed = [x for x in machine.operation_history_full[before:] if x.get("op") == "failed"]
            if failed:
                raise ValueError(f"operation rejected at index {i}: {op['op']}: {failed[0].get('params', {}).get('message', '')}")
        # S01 v2.0.1 has no spawn_y argument and already exports global Y=5.
        # v2.1 introduced configurable spawn height; never patch release code.
        return machine.to_xml(spawn_y=5) if "spawn_y" in inspect.signature(machine.to_xml).parameters else machine.to_xml()


def replay(sub, source, mode="", registry_path=None, evidence_dir=None):
    out = {"submission_id": sub.path.name, "run_package_sha256": package_hash(sub),
           "status": "review", "s01_version_verified": False, "attempts": []}
    if mode == "HumanBoss":
        out.update(status="not_required_human_boss", reason="Human Boss does not require AI build-history reconstruction")
        return out
    if sub.archive_errors:
        out.update(status="archive_unreadable", reason="; ".join(sub.archive_errors))
        return out
    if not any(m.name.lower().endswith(".bsg") for m in sub.members):
        out.update(status="missing_bsg", reason="No submitted BSG to compare")
        return out
    histories = history_candidates(sub)
    if not histories:
        has_history_file = any("history" in m.name.lower() and m.name.lower().endswith(".json") for m in sub.members)
        out.update(status="unsupported_history" if has_history_file else "missing_history",
                   reason="No replayable operation list found by content, including aliases and embedded valid history")
        return out
    for member, history, history_name, scope in histories:
        attempt = {"history_source": member.source, "history_sha256": member.sha256,
                   "history_scope": scope, "history_operation_count": len(history)}
        out["attempts"].append(attempt)
        try:
            reconstructed = replay_history(sub, source, history, registry_path)
            attempt["reconstructed_bsg_sha256"] = hashlib.sha256(reconstructed.encode()).hexdigest()
            nodes = ET.fromstring(reconstructed).findall("Blocks/Block")
            attempt["reconstructed_block_count"] = len(nodes)
            attempt["reconstructed_type_counts"] = dict(Counter(b.get("id") for b in nodes))
            if evidence_dir is not None:
                evidence_dir.mkdir(parents=True, exist_ok=True)
                bsg_path = evidence_dir / f"{sub.path.name.split('_')[0]}_{member.sha256[:12]}.bsg"
                bsg_path.write_text(reconstructed, encoding="utf-8", newline="\n")
                attempt["reconstructed_bsg_path"] = str(bsg_path)
            candidates, basis = raw_candidates(sub, history_name)
            attempt["raw_binding_basis"] = basis
            attempt["comparisons"] = []
            for raw in candidates:
                changes = compare_structure(raw.data, reconstructed, replay=True)
                attempt["comparisons"].append({"bsg_source": raw.source, "bsg_sha256": raw.sha256,
                                                "matched": not changes, "changes": changes})
            attempt["status"] = "matched" if any(c["matched"] for c in attempt["comparisons"]) else "structure_mismatch"
        except Exception as e:
            attempt.update(status="replay_error", reason=str(e), error_type=type(e).__name__)
    matched = [a for a in out["attempts"] if a["status"] == "matched"]
    out["status"] = "matched_current_runtime" if matched else "current_runtime_mismatch" if any(a["status"] == "structure_mismatch" for a in out["attempts"]) else "replay_error"
    out["matched_history_count"] = len(matched)
    out["final_run_selected"] = False
    out["reason"] = ("Independent history/BSG comparison; this does not select a final run or certify every artifact"
                     if matched else "; ".join(a.get("reason", "reconstructed structure differs from submitted BSG candidates") for a in out["attempts"]))
    return out


def rebuild(input_root, source):
    from .pipeline import RULES, load_config, read_json, digest
    source = Path(source).resolve()
    release = read_json(RULES/'release.json')
    expected = release['source_files_sha256']
    if any(not (source/name).is_file() or digest(source/name)!=sha for name,sha in expected.items()):
        raise ValueError('Source files do not match pinned official S01 v2.0.1')
    original = source/'blocks/block_registry.generated.toml'
    with (RULES/'modes.csv').open(encoding='utf-8-sig',newline='') as f:
        modes={r['submission_id']:r['detected_mode'] for r in csv.DictReader(f)}
    load_config()
    rows=[]
    # Availability-only adapter restores vanilla automation allowed by S01.
    # S01 allows these vanilla automation blocks, even when the authoring
    # catalog hides them. The submitted history and all geometry stay intact.
    import tempfile
    with tempfile.TemporaryDirectory(prefix='s01-registry-') as temporary:
        adapted=Path(temporary)/'registry.toml'
        adapter=replay_registry(source,adapted)
        os.environ['BLOCK_REGISTRY_PATH'] = str(adapted)
        sys.path.insert(0,str(source))
        from buildarena import build
        if Path(build.__file__).resolve() != source/'buildarena/build.py':
            raise ValueError('A different BuildArena runtime was already imported')
        for path in sorted(Path(input_root).resolve().iterdir()):
            if not path.is_dir():
                continue
            sub=Submission(path)
            r=replay(sub,source,modes.get(path.name,''),adapted)
            r['registry_adapter']=adapter
            r.pop('s01_version_verified',None)
            r['version_check_status']='passed_by_organizer_instruction'
            rows.append(r)
            print(path.name.split('_')[0],r['status'],flush=True)
    data={'official_source':str(source),'runtime_source_sha256':expected,
          'source_release':release['release_tag'],'rows':rows,
          'status_counts':dict(Counter(r['status'] for r in rows))}
    (RULES/'reconstruction.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

