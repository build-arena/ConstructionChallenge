"""Fixed S01 costs, two-stage ranking, and technical prize allocation."""
import hashlib
import json
import math
from collections import Counter, defaultdict
from datetime import datetime, timezone
from functools import lru_cache
from pathlib import Path

from .artifacts import resolve_artifact, operation_list
from .evidence import ScoreIssue

def validate_cost(c):
    weights = [float(c[k]) for k in ('block_weight', 'token_weight')]
    weights.append(float(c.get('error_weight', 0)))
    if any((not math.isfinite(w) or w < 0 for w in weights)) or not math.isclose(sum(weights), 1, abs_tol=1e-12):
        raise ValueError('invalid cost weights')
    if 'error_weight' in c and (weights != [0.4, 0.3, 0.3] or c['penalty_weight'] != 1 or c['max_penalty'] != 100):
        raise ValueError('S01 published cost requires fixed 40/30/30 weights, coefficient 1 and cap 100')
    for key in ('block_reference', 'token_reference'):
        if not math.isfinite(float(c[key])) or c[key] <= 0:
            raise ValueError('cost references must be finite and positive')

def cost_components(row, c):
    validate_cost(c)

    def number(key):
        value = row.get(key)
        if value is None or isinstance(value, bool):
            raise ValueError('missing or invalid cost metric: ' + key)
        value = float(value)
        if not math.isfinite(value) or value < 0:
            raise ValueError('invalid cost metric: ' + key)
        return value
    mechanical = 100 * c['block_weight'] * min(1, number(c.get('mechanical_metric', 'block_count')) / c['block_reference'])
    token = 100 * c['token_weight'] * min(1, number('cleaned_token_count') / c['token_reference'])
    error = 0.0
    if c.get('error_weight', 0):
        ratio = number('failed_operation_ratio')
        if ratio > 1:
            raise ValueError('failed operation ratio must be in [0,1]')
        error = 100 * c['error_weight'] * ratio
    total = mechanical + token + error
    scale = min(1, c['max_penalty'] / total) if total else 1
    multiplier = c['penalty_weight'] * scale
    return {'cost_penalty': min(c['max_penalty'], total), 'mechanical_deduction_points': multiplier * mechanical, 'token_deduction_points': multiplier * token, 'error_deduction_points': multiplier * error, 'total_deduction_points': c['penalty_weight'] * min(c['max_penalty'], total)}

def error_metrics(sub):
    try:
        member = resolve_artifact(sub, 'build_history_full.json')
    except ScoreIssue as exc:
        raise ScoreIssue('review', 'error_cost_full_history_unavailable', detail=exc.reason) from exc
    try:
        operations = json.loads(member.data)
    except (ValueError, UnicodeError) as exc:
        raise ScoreIssue('review', 'error_cost_full_history_invalid') from exc
    if not operation_list(operations):
        raise ScoreIssue('review', 'error_cost_full_history_invalid')
    failed = sum((op['op'] == 'failed' for op in operations))
    total = len(operations)
    return {'failed_operation_count': failed, 'full_history_operation_count': total, 'failed_operation_ratio': failed / total, 'error_history_source': member.source, 'error_history_sha256': member.sha256, 'error_cost_basis': 'explicit op=failed / all full-history operation records'}

@lru_cache(maxsize=4)
def catalog(expected_sha256=None):
    data = (Path(__file__).resolve().parents[1] / 'rules/block_points.json').read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    if expected_sha256 and digest != expected_sha256:
        raise ScoreIssue('review', 'block_points_catalog_hash_mismatch')
    return (json.loads(data), digest)

def machine_cost(blocks, cfg):
    table, digest = catalog(cfg.get('cost', {}).get('block_points_catalog_sha256'))
    unknown = sorted({block['type_id'] for block in blocks.values()} - set(table['blocks']))
    if unknown:
        raise ScoreIssue('review', 'block_points_unknown_type', block_ids=unknown)
    counts = Counter((block['type_id'] for block in blocks.values()))
    detail = [{'block_id': key, 'name': table['blocks'][key]['name'], 'count': count, 'points_each': table['blocks'][key]['points'], 'subtotal': count * table['blocks'][key]['points'], 'rule': table['blocks'][key].get('rule', 'fixed')} for key, count in sorted(counts.items(), key=lambda item: int(item[0]))]
    return (sum((row['subtotal'] for row in detail)), {'definition': table['definition'], 'catalog_sha256': digest, 'catalog_source_sha256': table['source_sha256'], 'source_release': table['source_release'], 'breakdown': detail})

def finite(value, name):
    value = float(value)
    if not math.isfinite(value):
        raise ValueError(f'{name} must be finite')
    return value

def dynamic_linear(value, best, weight, floor, gate_passed=True):
    value, best, weight, floor = [finite(v, n) for v, n in zip((value, best, weight, floor), ('value', 'best', 'weight', 'floor'))]
    if min(value, best, weight, floor) < 0 or floor > weight:
        raise ValueError('invalid dynamic grading bounds')
    if not gate_passed or value == 0:
        return 0.0
    if best <= 0 or value > best:
        raise ValueError('reference best must cover every positive gate-passing value')
    return floor + (weight - floor) * value / best

def valid_time(value):
    stamp = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
    if stamp.tzinfo is None:
        raise ValueError('valid final submission time must include timezone')
    return stamp.astimezone(timezone.utc)

def score_pool(rows, cfg, *, reference_best=None, diagnostic=False):
    p, c = (cfg['performance'], cfg['cost'])
    floor_ratio = finite(cfg['relative_speed']['passing_floor_ratio'], 'floor_ratio')
    if not 0 <= floor_ratio <= 1:
        raise ValueError('floor ratio must be in [0,1]')
    best = max((finite(r['mean_angular_speed_rad_s'], 'omega') for r in rows if r['gate_passed']), default=0.0)
    if reference_best is not None:
        best = finite(reference_best, 'reference_best')
        if best < 0:
            raise ValueError('negative reference best')
    result = []
    for source in rows:
        r = dict(source)
        r.pop('provisional_score', None)
        r['score_version'] = cfg['score_version']
        speed_weight = p['max_score'] * p['speed_weight']
        omega = r['mean_angular_speed_rad_s']
        if diagnostic:
            omega = min(finite(omega, 'omega'), best)
        speed_points = dynamic_linear(omega, best, speed_weight, speed_weight * floor_ratio, r['gate_passed'])
        performance = p['max_score'] * (p['orbit_weight'] * finite(r['orbit_progress'], 'progress') + p['integrity_weight'] * finite(r['structure_integrity'], 'integrity')) + speed_points
        components = cost_components(r, c)
        cost = components['cost_penalty']
        r.update(components)
        raw_base = performance - c['penalty_weight'] * cost
        base = max(0.0, raw_base)
        coefficient = cfg['mode_coefficients'][r['detected_mode']]
        r.update(speed_reference_best=best, speed_points=speed_points, speed_score=speed_points / speed_weight if speed_weight else 0.0, performance_score=performance, cost_penalty=cost, base_score=base, mode_coefficient=coefficient, final_score=base * coefficient, raw_base_score=raw_base, raw_final_score=raw_base * coefficient)
        result.append(r)
    return result

def tie_key(r):
    return (-r['final_score'], -r['raw_final_score'], -r['performance_score'], r['cost_penalty'], _time(r), r['submission_id'])

def rank_two_stage(rows, cfg, *, provisional=False):
    groups = defaultdict(list)
    ids = set()
    for row in rows:
        if provisional:
            if row.get('compliance_status') not in {'review', 'accepted'} or row.get('auto_technical_passed') is not True:
                raise ValueError('provisional scoring requires technical checks and excludes invalid/DQ/exhibition')
        elif row.get('compliance_status') != 'accepted' or row.get('competitive_eligible') is not True:
            raise ValueError('only accepted competitive packages may enter either pool')
        if not row.get('team_id') or not row.get('run_package_sha256'):
            raise ValueError('team identity and complete package hash are required')
        if row['submission_id'] in ids:
            raise ValueError('duplicate submission ID')
        ids.add(row['submission_id'])
        if not provisional:
            valid_time(row['valid_final_submission_time'])
        if type(row.get('gate_passed')) is not bool:
            raise ValueError('gate_passed must be a boolean')
        for name in {'mean_angular_speed_rad_s', 'block_count', 'cleaned_token_count', cfg['cost'].get('mechanical_metric', 'block_count')}:
            if finite(row[name], name) < 0:
                raise ValueError(f'negative {name}')
        for name in ('orbit_progress', 'structure_integrity'):
            if not 0 <= finite(row[name], name) <= 1:
                raise ValueError(f'{name} outside [0,1]')
        groups[row['team_id']].append({**row, 'ranking_kind': 'provisional' if provisional else 'final'})
    local, winners = ([], [])
    for team in sorted(groups):
        scored = sorted(score_pool(groups[team], cfg), key=tie_key)
        winner = scored[0]['submission_id']
        for r in scored:
            r.update(team_local_score=r['final_score'], team_local_raw_score=r['raw_final_score'], team_local_performance_score=r['performance_score'], team_local_speed_reference_best=r['speed_reference_best'], effective_final_submission=r['submission_id'] == winner)
        local.extend(scored)
        winners.append(scored[0])
    final = sorted(score_pool(winners, cfg), key=tie_key)
    for rank, row in enumerate(final, 1):
        row['rank'] = rank
    return (local, final)

def _number(value, field):
    if isinstance(value, bool):
        raise ValueError(f'{field} must be a finite nonnegative number')
    try:
        value = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f'{field} must be a finite nonnegative number') from exc
    if not math.isfinite(value) or value < 0:
        raise ValueError(f'{field} must be a finite nonnegative number')
    return value

def _is_false(value):
    return value is False or str(value).strip().lower() in {'false', '0'}

def _time(row):
    value = row.get('valid_final_submission_time')
    if not value and row['ranking_kind'] == 'provisional':
        return datetime.max.replace(tzinfo=timezone.utc)
    try:
        return valid_time(value)
    except ValueError as exc:
        raise ValueError('final awards require a valid final submission timestamp') from exc

def _prepare(global_rows):
    rows, teams, ids, kinds = ([], set(), set(), set())
    for source in global_rows:
        row = dict(source)
        for field in ('submission_id', 'team_id'):
            if not isinstance(row.get(field), str) or not row[field].strip():
                raise ValueError(f'{field} is required')
        if row['team_id'] in teams or row['submission_id'] in ids:
            raise ValueError('awards require the one-entry-per-team global final pool')
        teams.add(row['team_id'])
        ids.add(row['submission_id'])
        kind = row.get('ranking_kind', 'final')
        if kind not in {'final', 'provisional'}:
            raise ValueError('unsupported ranking_kind')
        row['ranking_kind'] = kind
        kinds.add(kind)
        status = str(row.get('compliance_status', '')).casefold()
        if status and status not in ({'accepted', 'review'} if kind == 'provisional' else {'accepted'}):
            raise ValueError('DQ, invalid, exhibition or unverified formal entries cannot receive awards')
        if any((_is_false(row.get(field)) for field in ('competitive_eligible', 'auto_technical_passed', 'effective_final_submission'))):
            raise ValueError('ineligible or unselected entries cannot receive awards')
        if row.get('detected_mode') not in {'Autopilot', 'Copilot'}:
            raise ValueError('only competitive Autopilot/Copilot entries may receive awards')
        for field in ('final_score', 'performance_score', 'cost_penalty', 'machine_cost_points'):
            row[field] = _number(row.get(field), field)
        row['raw_final_score'] = finite(row['raw_final_score'], 'raw_final_score')
        row['_tie_time'] = _time(row)
        rows.append(row)
    if len(kinds) > 1:
        raise ValueError('formal and provisional pools must be allocated separately')
    return (rows, next(iter(kinds), 'final'))

def _holder(row, metric):
    if row is None:
        return None
    result = {key: row[key] for key in ('submission_id', 'team_id', 'detected_mode', 'ranking_kind', 'final_score', 'raw_final_score', 'performance_score', 'cost_penalty', 'machine_cost_points')}
    result['award_metric'] = metric(row)
    result['pending_review'] = row['ranking_kind'] == 'provisional'
    result['review_label'] = row.get('review_label') or ('待复核' if result['pending_review'] else '正式')
    if result['pending_review'] and '待复核' not in result['review_label']:
        result['review_label'] = '待复核：' + str(result['review_label'])
    if row.get('valid_final_submission_time'):
        result['valid_final_submission_time'] = row['valid_final_submission_time']
    return result

def allocate_awards(global_rows, cfg):
    """Return five JSON-serializable award records, in cash de-duplication order.

    Each record keeps the original title holder even when cash rolls down.
    ``roll_down`` records skipped recipients and the higher-priority cash award
    they already hold. Empty categories stay unawarded. Thresholds use the full
    possible Performance score, not the best score observed in this pool.
    """
    maximum = _number(cfg['performance']['max_score'], 'performance.max_score')
    if maximum == 0:
        raise ValueError('performance.max_score must be positive')
    rows, kind = _prepare(global_rows)
    definitions = (('Agent Master Builder', 'final_score', 0.0, None, lambda r: r['final_score']), ('Powerful but Brutal', 'performance_score + machine_cost_points', 0.7, None, lambda r: r['performance_score'] + r['machine_cost_points']), ('Cheap Thrills', 'performance_score - 2 * machine_cost_points', 0.6, None, lambda r: r['performance_score'] - 2 * r['machine_cost_points']), ('Best Build Autopilot', 'final_score', 0.0, 'Autopilot', lambda r: r['final_score']), ('Best Build Copilot', 'final_score', 0.0, 'Copilot', lambda r: r['final_score']))
    allocated, result = ({}, [])
    for name, formula, floor_ratio, mode, metric in definitions:
        floor = maximum * floor_ratio
        candidates = [r for r in rows if r['performance_score'] >= floor and (mode is None or r['detected_mode'] == mode)]
        candidates.sort(key=lambda r: (-metric(r), -r['raw_final_score'] if formula == 'final_score' else 0, -r['performance_score'], r['cost_penalty'], r['_tie_time'], r['submission_id']))
        skipped, winner = ([], None)
        for row in candidates:
            previous = allocated.get(row['team_id'])
            if previous:
                skipped.append({'submission_id': row['submission_id'], 'team_id': row['team_id'], 'already_awarded': previous, 'reason': 'higher_priority_cash_award_already_allocated'})
            else:
                winner = row
                allocated[row['team_id']] = name
                break
        reason = None
        if not candidates:
            reason = 'empty_global_pool' if not rows else 'no_eligible_entry_in_build_mode' if mode else 'no_entry_meets_performance_threshold'
        elif winner is None:
            reason = 'all_eligible_entries_already_hold_higher_priority_cash_awards'
        result.append({'award': name, 'title_holder': _holder(candidates[0], metric) if candidates else None, 'cash_winner': _holder(winner, metric), 'metric': {'formula': formula, 'performance_floor_ratio': floor_ratio, 'performance_floor': floor, 'build_mode': mode, 'cost_definition': 'sum of Besiege Block Points (machine_cost_points)'}, 'eligible_count': len(candidates), 'roll_down': skipped, 'unawarded_reason': reason, 'ranking_kind': kind, 'pending_review': kind == 'provisional', 'review_label': '待复核' if kind == 'provisional' else '正式'})
    return result
