"""Static results page. JavaScript filters rows; it never calculates scores."""
import html
import math
import os
from pathlib import Path


def esc(value):
    return html.escape(str(value), quote=True)


def number(value, digits=3):
    return 'N/A' if value in (None, '') else f'{float(value):.{digits}f}'


def display_score(row):
    if row.get('final_score') is None:
        return 'N/A'
    raw = row['raw_final_score']
    return f'0（{raw:.3f}）' if raw < 0 else number(row['final_score'])


def table(headers, rows, css=''):
    return ('<div class="scroll"><table class="'+css+'"><thead><tr>' +
            ''.join(f'<th>{esc(h)}</th>' for h in headers)+'</tr></thead><tbody>' +
            ''.join('<tr>'+''.join(f'<td>{cell}</td>' for cell in row)+'</tr>' for row in rows)+
            '</tbody></table></div>')


def reason_label(reason):
    return {'error_cost_full_history_unavailable':'缺少可确定归属的 full history，不计算总分',
            'error_cost_full_history_invalid':'full history 格式无效，不计算总分',
            'disqualified':'已裁定 DSQ', 'invalid':'必要材料缺失或无效',
            'exhibition':'Human Boss 展示组',
            'reconstruction_missing_or_stale':'缺少与当前提交包匹配的重建证据',
            'exact_raw_history_reconstruction_not_matched':'构建历史无法重建提交机器',
            'legacy_proxy_schema_incomplete':'缺少必要轨迹字段'}.get(reason, reason)


def render(result, target):
    cfg, summary = result['config'], result['summary']
    root = Path(__file__).resolve().parents[1]
    target = Path(target)
    legacy = result['provenance']['scoring_profile'] == 'legacy'
    label = '历史错误结果 · 仅供复现' if legacy else '修正后的最终结果'
    config_path = root/'rules'/('legacy/config_s01.json' if legacy else 'config_s01.json')
    config_link = esc(Path(os.path.relpath(config_path, target.parent)).as_posix())
    docs_link = esc(Path(os.path.relpath(root/'docs'/'REPRODUCING_S01.md', target.parent)).as_posix())
    cost = cfg['cost']
    rows = []
    for r in result['ranking']:
        rows.append([str(r['rank']), f'<b>{esc(r["team_id"])}</b><small>{esc(r["submission_id"])}</small>',
                     f'<b>{display_score(r)}</b><small>队内 {display_score(dict(r,final_score=r["team_local_score"],raw_final_score=r["team_local_raw_score"]))}</small>',
                     f'{number(70*r["orbit_progress"])}<small>{number(r["angular_displacement_rad"]/math.tau)} 圈</small>',
                     f'{number(r["speed_points"])}<small>{number(r["mean_angular_speed_rad_s"],5)} rad/s<br>{number(r["valid_time_s"],1)} s</small>',
                     number(10*r['structure_integrity']), number(r['performance_score']),
                     f'−{number(r["mechanical_deduction_points"])}<small>{r["machine_cost_points"]:g} 点</small>',
                     f'−{number(r["token_deduction_points"])}<small>{r["cleaned_token_count"]:g} tokens</small>',
                     f'−{number(r["error_deduction_points"])}<small>{r["failed_operation_count"]}/{r["full_history_operation_count"]} failed<br>{r["failed_operation_ratio"]:.2%}</small>',
                     f'−{number(r["total_deduction_points"])}',number(r['raw_base_score']),
                     f'{esc(r["detected_mode"])}<small>×{r["mode_coefficient"]:g}</small>'])
    ranking=table(['名次','队伍 / 有效提交','最终分','轨道 / 70','速度 / 20','完整度 / 10','性能合计',
                   '机械扣分','Token 扣分','错误扣分','扣分合计','未归零基础分','模式'],rows,'scores')
    awards=table(['奖项','展示头衔','现金奖归属','评奖依据','递补说明'],[
        [esc(a['award']),esc((a['title_holder'] or {}).get('team_id','空缺')),
         esc((a['cash_winner'] or {}).get('team_id','空缺')),esc(a['metric']['formula']),
         esc('；'.join(x['team_id']+' 已获 '+x['already_awarded'] for x in a['roll_down']) or '—')]
        for a in result['awards']])
    dsq=table(['状态','队伍 / 提交','展示分','机械点数','排除原因','数据不足说明'],[
        ['DSQ',esc(r['submission_id']),display_score(r),number(r.get('machine_cost_points'),0),esc(r['reason']),
         esc(reason_label(r['metric_reason'])) if r['metric_status']!='ready' else '仅展示，不参加排名及奖项']
        for r in result['dsq']])
    excluded=table(['提交','未进入总分排名的原因'],[
        [esc(r['submission_id']),esc(reason_label(r['reason']))] for r in result['excluded']])
    audit=table(['提交','机器校验状态','结构比对','核验说明'],[
        [esc(r['submission_id']),esc(r['compliance_status']),esc(r['checks'].get('raw_tuned_structure','N/A')),
         esc('；'.join(i for i in r['issues'] if not i.startswith('pending_verifier_check:')) or '自动检查通过；历史回执字段保留原样')]
        for r in result['audits']])
    page=f'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>BuildArena S01 · {label}</title><style>
body{{margin:0;background:#f4f6fa;color:#17243b;font:15px/1.65 system-ui,sans-serif}}main{{max-width:1700px;margin:auto;padding:28px}}section,details{{background:white;border:1px solid #dce3ed;border-radius:10px;padding:22px;margin:20px 0}}h1,h2{{margin:0 0 12px}}small{{display:block;color:#617087;font-size:12px}}.scroll{{overflow:auto}}table{{border-collapse:collapse;width:100%;font-variant-numeric:tabular-nums}}th,td{{text-align:left;padding:10px;border-bottom:1px solid #e4e9f1;vertical-align:top}}th{{background:#eef2f8;white-space:nowrap}}.scores{{min-width:1650px}}.scores td:nth-child(2){{min-width:220px;max-width:260px;overflow-wrap:anywhere}}.scores td:nth-child(3){{color:#1957b9;white-space:nowrap}}a{{color:#1957b9}}input{{font:inherit;padding:8px 12px;max-width:90%;width:360px;border:1px solid #b6c4d6;border-radius:6px}}code{{background:#eef2f8;padding:2px 5px}}summary{{cursor:pointer;font-weight:600}}</style></head><body><main>
<h1>BuildArena S01 · {label}</h1><p>{summary['submissions']} 份提交 · {summary['scored']} 份计分 · {summary['teams']} 队 · {summary['zero_teams']} 队最终分为零</p>
<p><b>{'此页使用错误中心，不代表最终排名或奖金归属。' if legacy else '组织方已完成复核；最终排名及奖金归属以修正结果和正式声明为准，不以已冻结的 Kaggle Winner 标签为准。'}</b> 轨道计角中心：<code>{esc(cfg['scene']['orbit_center'])}</code>。</p>
<section><h2>固定规则</h2><p>机械参考 <b>{cost['block_reference']:g} 点</b>，Token 参考 <b>{cost['token_reference']:g}</b>；成本固定 40% / 30% / 30%，扣分系数 1。机械成本使用 Besiege 模块点数，错误率使用同份 full history 中 failed 条数 / 全部操作条数。</p>
<p><code>未归零分数 = (性能 − 机械扣分 − Token扣分 − 错误扣分) × 模式系数</code>；最终分取它与 0 的较大值。负数显示为 <b>0（负数）</b>，括号内数值已乘模式系数。</p>
<p>队内选优及全局排序均按最终分、未归零分数、性能分从高到低，再按成本从低到高和经核验时间从早到晚。队内选定提交后冻结，全局重算不重新选人。未核验时间的暂行同分按提交 ID 排列。缺必要数据为 N/A，不冒充零分；DSQ 不参与排名、参考值或奖项。</p>
<p>轨道分 3 圈封顶 70；超出圈数仍计入平均角速度。速度为 <code>8 + 12 × ω/ω_best</code>，正值且通过门槛才计分。计圈从首次入轨至记录结束或 900 秒上限，速度计时包含入轨前时间。完整度为 Tracker 健康比近似值。Autopilot ×1.15，Copilot ×1。</p>
<p><a href="result.json">完整结果与证据 JSON</a> · <a href="{config_link}">固定配置</a> · <a href="{docs_link}">复现说明</a></p></section>
<label for="search">搜索队伍、提交或原因</label><p><input id="search" type="search" placeholder="输入队名、作品名或编号"></p>
<section><h2>排名与评分分项 · {label}</h2>{ranking}<p>括号中的未归零分数用于零分项目排序；计算不做中间显示舍入。</p></section>
<section><h2>技术赛道奖项 · {label}</h2><p>Brutal 要求性能 ≥70；Cheap 要求性能 ≥60。展示头衔可以重复，技术奖金每队最多一项，按 Master → Brutal → Cheap → Best Build Autopilot → Best Build Copilot 递补。社区奖由组织方另行确认，不由评分程序计算。</p>{awards}</section>
<section><h2>DSQ 机器展示</h2>{dsq}</section>
<section><h2>未进入总分排名</h2>{excluded}</section>
<details><summary>逐份校验证据</summary>{audit}</details>
<p>JSON 中 review/provisional、formal_ranking 等字段沿用原始审计记录；回执文件未补录，程序不伪造回执。这些历史字段不代表组织方重新开启复核。历史完整版本保存在 Git 提交 00d1730。当前版本 {esc(cfg['score_version'])}。</p>
</main><script>document.getElementById('search').addEventListener('input',e=>{{let q=e.target.value.toLocaleLowerCase();for(let row of document.querySelectorAll('tbody tr'))row.hidden=!row.textContent.toLocaleLowerCase().includes(q)}});</script></body></html>'''
    target.write_text(page,encoding='utf-8')
