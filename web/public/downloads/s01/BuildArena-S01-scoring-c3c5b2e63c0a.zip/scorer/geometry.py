"""Recognize vanilla Fuel Line endpoint-preserving save normalization.

Official build.py Connector uses R.T @ (end.center - start.center) for
positions, but exports endpoint normal.euler directly (machine coordinates).
Endpoint rotations must therefore NOT be multiplied by the block rotation.
This helper covers only Transform and the four endpoint fields. Callers must
still compare all other attributes, structural children, and Data fields.
"""
import math
ENDPOINT_KEYS = frozenset({'start-position', 'end-position', 'start-rotation', 'end-rotation'})

def _numbers(values):
    result = tuple((float(x) for x in values))
    if not all((math.isfinite(x) for x in result)):
        raise ValueError('nonfinite geometry')
    return result

def _close(a, b, tolerance):
    return all((abs(x - y) <= tolerance for x, y in zip(a, b)))

def _quat_equal(a, b, tolerance):
    return _close(a, b, tolerance) or _close(a, tuple((-x for x in b)), tolerance)

def _euler(node):
    x, y, z = (math.radians(math.remainder(v, 360)) / 2 for v in _numbers((node.findtext(k) for k in 'XYZ')))
    sx, cx, sy, cy, sz, cz = (math.sin(x), math.cos(x), math.sin(y), math.cos(y), math.sin(z), math.cos(z))
    return (cy * sx * cz + sy * cx * sz, sy * cx * cz - cy * sx * sz, cy * cx * sz - sy * sx * cz, cy * cx * cz + sy * sx * sz)

def _geometry(block, tolerance):
    tr = block.find('Transform')
    if tr is None or tr.attrib or len(tr) != 3 or ({x.tag for x in tr} != {'Position', 'Rotation', 'Scale'}):
        raise ValueError('unknown transform schema')
    values = []
    for tag, keys in (('Position', 'xyz'), ('Rotation', 'xyzw'), ('Scale', 'xyz')):
        node = tr.find(tag)
        if set(node.attrib) != set(keys) or len(node):
            raise ValueError('unknown transform fields')
        values.append(_numbers((node.get(k) for k in keys)))
    position, quaternion, scale = values
    if abs(sum((x * x for x in quaternion)) - 1) > tolerance or any((x <= 0 for x in scale)):
        raise ValueError('invalid quaternion or scale')
    norm = math.sqrt(sum((x * x for x in quaternion)))
    x, y, z, w = (v / norm for v in quaternion)
    matrix = ((1 - 2 * y * y - 2 * z * z, 2 * x * y - 2 * z * w, 2 * x * z + 2 * y * w), (2 * x * y + 2 * z * w, 1 - 2 * x * x - 2 * z * z, 2 * y * z - 2 * x * w), (2 * x * z - 2 * y * w, 2 * y * z + 2 * x * w, 1 - 2 * x * x - 2 * y * y))
    endpoints, rotations = ([], [])
    for prefix in ('start', 'end'):
        pair = []
        for suffix in ('position', 'rotation'):
            nodes = block.findall("Data/*[@key='" + prefix + '-' + suffix + "']")
            if len(nodes) != 1:
                raise ValueError('missing or duplicate endpoint')
            node = nodes[0]
            if node.tag != 'Vector3' or set(node.attrib) != {'key'} or len(node) != 3 or ({c.tag for c in node} != set('XYZ')) or any((c.attrib or len(c) for c in node)):
                raise ValueError('unknown endpoint schema')
            pair.append(node)
        local = _numbers((pair[0].findtext(k) for k in 'XYZ'))
        scaled = tuple((a * b for a, b in zip(local, scale)))
        endpoints.append(tuple((p + sum((a * b for a, b in zip(row, scaled))) for p, row in zip(position, matrix))))
        rotations.append(_euler(pair[1]))
    length = math.sqrt(sum(((a - b) ** 2 for a, b in zip(*endpoints))))
    return (scale, endpoints, rotations, length)

def fuel_line_geometry_equal(before, after, tolerance=0.001):
    """Return True only for complete, equivalent id96 connector geometry."""
    if before.get('id') != '96' or after.get('id') != '96':
        return False
    try:
        a, b = (_geometry(before, tolerance), _geometry(after, tolerance))
        return _close(a[0], b[0], tolerance) and all((_close(x, y, tolerance) for x, y in zip(a[1], b[1]))) and all((_quat_equal(x, y, tolerance) for x, y in zip(a[2], b[2]))) and (abs(a[3] - b[3]) <= tolerance)
    except (ValueError, TypeError, AttributeError, OverflowError):
        return False
import copy
import re
import xml.etree.ElementTree as ET
GUID = re.compile('[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}', re.I)

def unique_guid_mapping(raw, tuned):
    """Return raw->tuned GUID bijection or None when equivalence is unproven.

    A distinct type+Transform match is required for every block. Geometry and
    block-level references are then compared after mapping GUID references.
    Existing GUID identities cannot be reassigned by a partially changed file.
    """
    from .compliance import blocks, geometry_data, xml_equal
    a, b = (blocks(raw), blocks(tuned))
    if len(a) != len(b) or not a or set(a) & set(b):
        return None
    mapping = {}
    for guid, before in a.items():
        candidates = [other for other, after in b.items() if before.get('id') == after.get('id') and xml_equal(before.find('Transform'), after.find('Transform'))]
        if len(candidates) != 1:
            return None
        mapping[guid] = candidates[0]
    if len(set(mapping.values())) != len(mapping):
        return None
    inverse = {value: key for key, value in mapping.items()}

    def normalized(node):
        node = copy.deepcopy(node)
        for child in node.iter():
            child.attrib = {key: GUID.sub(lambda m: inverse.get(m[0].lower(), m[0]), value) for key, value in child.attrib.items()}
            if child.text:
                child.text = GUID.sub(lambda m: inverse.get(m[0].lower(), m[0]), child.text)
        return node

    def references(block):
        return {(child.tag, child.get('key', '')): child for child in block.findall('Data/*') if GUID.search(ET.tostring(child, encoding='unicode'))}
    for guid, before in a.items():
        after = normalized(b[mapping[guid]])
        if before.attrib != after.attrib:
            return None
        left, right = (geometry_data(before), geometry_data(after))
        left.update(references(before))
        right.update(references(after))
        if set(left) != set(right) or any((not xml_equal(left[k], right[k]) for k in left)):
            return None
        x = [n for n in before if n.tag not in {'Transform', 'Data'}]
        y = [n for n in after if n.tag not in {'Transform', 'Data'}]
        if len(x) != len(y) or any((not xml_equal(m, n) for m, n in zip(x, y))):
            return None
    ra, rb = (ET.fromstring(raw), normalized(ET.fromstring(tuned)))
    x = [n for n in ra if n.tag not in {'Global', 'Data', 'Blocks'}]
    y = [n for n in rb if n.tag not in {'Global', 'Data', 'Blocks'}]
    if len(x) != len(y) or any((not xml_equal(m, n) for m, n in zip(x, y))):
        return None
    return mapping
