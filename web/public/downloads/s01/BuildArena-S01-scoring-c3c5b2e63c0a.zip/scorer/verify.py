"""Recheck saved scores and their original input evidence without simulation."""
from pathlib import Path
from .pipeline import ROOT, RULES, read_json, load_config, digest, blocker, check_reconstruction, config_directory
from .evidence import Submission
from .compliance import package_hash
from .scoring import error_metrics, rank_two_stage, score_pool, allocate_awards


def verify(input_root=ROOT/'raw_submissions', result_path=None, *, profile='corrected'):
    cfg = load_config(profile)
    result = read_json(result_path or ROOT/'results'/profile/'result.json')
    assert result['provenance']['scoring_profile'] == profile, 'Saved profile differs'
    assert result['provenance']['selected_config_sha256'] == digest(config_directory(profile)/'config_s01.json'), 'Selected profile configuration changed'
    assert result['config'] == cfg, 'Saved configuration differs from frozen configuration'
    for name, sha in result['provenance']['rules'].items():
        assert digest(RULES/name) == sha, 'Stale rule/evidence file: '+name
    for name, sha in result['provenance']['code'].items():
        assert digest(ROOT/'scorer'/name) == sha, 'Stale scorer: '+name
    assert digest(ROOT/'score.py') == result['provenance']['entrypoint_sha256'], 'Stale entrypoint'
    paths = {p.name:p for p in Path(input_root).resolve().iterdir() if p.is_dir()}
    audits = {r['submission_id']:r for r in result['audits']}
    assert paths.keys() == audits.keys(), 'Submission inventory differs'
    history = {}
    for sid,path in paths.items():
        sub = Submission(path)
        assert package_hash(sub) == audits[sid]['run_package_sha256'], 'Stale submission: '+sid
        try:
            history[sid] = error_metrics(sub)
        except Exception:
            pass
    rebuilt = {r['submission_id']:r for r in check_reconstruction(cfg)['rows']}
    for r in result['team_local']:
        sid = r['submission_id']
        assert not blocker(audits[sid], rebuilt.get(sid), r['team_id']), 'Gate failed: '+sid
        assert sid in history, 'Scored without full history: '+sid
        for k in ('error_history_sha256','failed_operation_count','full_history_operation_count','failed_operation_ratio'):
            assert r[k] == history[sid][k], 'Wrong history metric: '+sid+':'+k
    local, ranking = rank_two_stage(result['team_local'],cfg,provisional=True)
    assert local == result['team_local'], 'Local scoring/selection differs'
    assert ranking == result['ranking'], 'Global scoring/order differs'
    assert allocate_awards(ranking,cfg) == result['awards'], 'Award allocation differs'
    accepted = [r for r in local if r['compliance_status']=='accepted' and r['competitive_eligible']]
    _, formal = rank_two_stage(accepted,cfg)
    assert formal == result['formal_ranking'], 'Formal pool differs'
    assert allocate_awards(formal,cfg) == result['formal_awards'], 'Formal awards differ'
    ranked_ids = {r['submission_id'] for r in ranking}
    best = max((r['mean_angular_speed_rad_s'] for r in ranking if r['gate_passed']),default=0.)
    for r in result['dsq']:
        assert r['submission_id'] not in ranked_ids and r['award_eligible'] is False
        assert audits[r['submission_id']]['compliance_status'] in {'invalid','disqualified'}
        if r['metric_status']=='ready':
            assert r['error_history_sha256']==history[r['submission_id']]['error_history_sha256']
            calculated=score_pool([r],cfg,reference_best=best,diagnostic=True)[0]
            for k in ('final_score','raw_final_score','cost_penalty','performance_score'):
                assert calculated[k]==r[k], 'DSQ score differs'
        else:
            assert r['final_score'] is None and r['metric_reason']
    print(f'Verified: {len(paths)} packages, {len(local)} scored submissions, {len(ranking)} teams.')
    return True
