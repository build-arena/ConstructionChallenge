"""Resolve submitted artifacts by role/schema; never rename or synthesize data."""
import json
from pathlib import PurePosixPath, Path
import re
import xml.etree.ElementTree as ET
from .evidence import Member, ScoreIssue, select_trajectory

def unique(candidates, role):
    by_hash = {m.sha256: m for m in candidates}
    if len(by_hash) > 1:
        raise ScoreIssue('review', 'ambiguous_artifact_role', role=role, sources=[m.source for m in by_hash.values()])
    if not by_hash:
        raise ScoreIssue('review', 'missing_artifact_role', role=role)
    return next(iter(by_hash.values()))

def operation_list(value):
    return isinstance(value, list) and bool(value) and all((isinstance(x, dict) and isinstance(x.get('op'), str) and isinstance(x.get('params'), dict) for x in value))

def history_candidates(sub):
    """Keep each history independent, including explicitly embedded RAW history."""
    candidates = []
    for m in sub.members:
        if not m.name.lower().endswith('.json') or 'full' in m.name.lower():
            continue
        try:
            value = json.loads(m.data)
        except (ValueError, UnicodeError):
            continue
        if operation_list(value):
            candidates.append((m, value, m.name, 'operation_list'))
        elif isinstance(value, dict):
            embedded = value.get('official_buildarena_valid_history', {})
            if isinstance(embedded, dict) and operation_list(embedded.get('operations')):
                candidates.append((m, embedded['operations'], embedded.get('source', {}).get('file', ''), 'official_buildarena_valid_history.operations'))
    by_hash = {}
    for candidate in candidates:
        signature = json.dumps(candidate[1], sort_keys=True)
        by_hash.setdefault(signature, candidate)
    return list(by_hash.values())

def raw_candidates(sub, history_name=''):
    bsgs = [m for m in sub.members if m.name.lower().endswith('.bsg')]
    stem = PurePosixPath(history_name).stem.casefold()
    paired = [m for m in bsgs if PurePosixPath(m.name).stem.casefold() == stem]
    if paired:
        return (list({m.sha256: m for m in paired}.values()), 'paired_history_basename')
    named = [m for m in bsgs if re.search('(^|[_ -])(raw|original)([_ .-]|$)|原始', m.name, re.I)]
    if named:
        return (list({m.sha256: m for m in named}.values()), 'explicit_raw_name')
    return (list({m.sha256: m for m in bsgs}.values()), 'bsg_candidates_raw_role_unverified')

def is_dialogue_text(data):
    """Recognize role-delimited dialogue, not a report mentioning an assistant."""
    text = data.decode('utf-8-sig', errors='replace')
    user = re.search('(?im)^\\s*#{1,6}\\s*[^\\w\\n]{0,12}(?:user|用户|human)\\b', text)
    assistant = re.search('(?im)^\\s*#{1,6}\\s*[^\\w\\n]{0,12}(?:assistant|助手|agent|ai|copilot|codex)\\b', text)
    return bool(user and assistant)

def dialogue_candidates(sub):
    candidates = [m for m in sub.members if m.name.lower().endswith(('.md', '.txt')) and is_dialogue_text(m.data)]
    normalized = {}
    for m in candidates:
        key = re.sub('\\s+', '', m.data.decode('utf-8-sig'))
        normalized.setdefault(key, m)
    return list(normalized.values())

def transcript_candidates(sub):
    result = dialogue_candidates(sub)
    for m in sub.members:
        if not m.name.lower().endswith(('.md', '.txt', '.json')):
            continue
        if re.search('chat|transcript|conversation|conversacion|session', m.name, re.I) and m.data.strip():
            if m.name.lower().endswith('.json'):
                try:
                    from .evidence import _json_messages
                    messages, _ = _json_messages(json.loads(m.data))
                    if not messages:
                        continue
                except (ValueError, UnicodeError):
                    continue
            result.append(m)
    if not result:
        result = [m for m in sub.members if m.name.lower().endswith(('.md', '.txt')) and re.search('build[_ -]?(?:process|log|report)|prompt|workflow|过程|建造记录', m.name, re.I) and m.data.strip()]
    return list({m.sha256: m for m in result}.values())

def replay_bound_pairs(sub):
    """Use only existing exact-package replay evidence to resolve raw/history."""
    from .compliance import package_hash
    path = Path(__file__).resolve().parents[1] / 'rules/reconstruction.json'
    if not path.exists():
        return []
    evidence = json.loads(path.read_text(encoding='utf-8'))
    row = next((r for r in evidence.get('rows', []) if r['submission_id'] == sub.path.name), None)
    if not row or row['run_package_sha256'] != package_hash(sub):
        return []
    pairs = []
    for attempt in row.get('attempts', []):
        for comparison in attempt.get('comparisons', []):
            if comparison.get('matched'):
                pairs.append((attempt['history_sha256'], comparison['bsg_sha256']))
    return pairs

def reviewed_bindings(sub):
    """Organizer review mappings bind original members; never synthesize a run."""
    from .compliance import package_hash
    path = Path(__file__).resolve().parents[1] / 'rules/bindings.json'
    if not path.exists():
        return {}
    record = json.loads(path.read_text(encoding='utf-8')).get(sub.path.name, {})
    if not record:
        return {}
    if record.get('run_package_sha256') != package_hash(sub):
        raise ScoreIssue('review', 'stale_artifact_binding')
    available = {m.sha256 for m in sub.members}
    if not record.get('evidence') or any((e.get('sha256') not in available for e in record['evidence'])):
        raise ScoreIssue('review', 'artifact_binding_evidence_missing')
    return record

def resolve_artifact(sub, role):
    record = reviewed_bindings(sub)
    if role in record.get('roles', {}):
        return unique([m for m in sub.members if m.sha256 == record['roles'][role]], role)
    exact = sub.named(role)
    if exact:
        return unique(exact, role)
    if role == 'trajectory.csv':
        return select_trajectory(sub)
    if role == 'build_history.json':
        candidates = [m for m, ops, name, scope in history_candidates(sub) if scope == 'operation_list']
        if len({m.sha256 for m in candidates}) > 1:
            matching = {h for h, b in replay_bound_pairs(sub)}
            if matching:
                candidates = [m for m in candidates if m.sha256 in matching]
        return unique(candidates, role)
    if role == 'build_history_full.json':
        candidates = []
        for m in sub.members:
            if m.name.lower().endswith('.json') and 'full' in m.name.lower():
                try:
                    if operation_list(json.loads(m.data)):
                        candidates.append(m)
                except (ValueError, UnicodeError):
                    pass
        return unique(candidates, role)
    if role == 'machine_raw.bsg':
        history = resolve_artifact(sub, 'build_history.json')
        candidates, basis = raw_candidates(sub, history.name)
        matching = {b for h, b in replay_bound_pairs(sub) if h == history.sha256}
        if matching:
            return unique([m for m in sub.members if m.sha256 in matching], role)
        if basis == 'bsg_candidates_raw_role_unverified':
            raise ScoreIssue('review', 'raw_role_unverified', sources=[m.source for m in candidates])
        return unique(candidates, role)
    if role == 'machine_tuned.bsg':
        candidates = [m for m in sub.members if m.name.lower().endswith('.bsg') and re.search('tuned|running|run[_ -]|controls.only|configured|submit|turned|[_-]fin[_-]|final|改键位|改建位', m.name, re.I)]
        if not candidates:
            single = {m.sha256: m for m in sub.members if m.name.lower().endswith('.bsg')}
            if len(single) == 1:
                return next(iter(single.values()))
            from .compliance import compare_structure
            raw = resolve_artifact(sub, 'machine_raw.bsg')
            for m in sub.members:
                if m.sha256 == raw.sha256 or not m.name.lower().endswith('.bsg'):
                    continue
                try:
                    if not compare_structure(raw.data, m.data):
                        candidates.append(m)
                except (ValueError, ET.ParseError):
                    continue
        return unique(candidates, role)
    if role == 'chat_transcript.md':
        candidates = transcript_candidates(sub)
        if not candidates:
            return unique([], role)
        return sorted(candidates, key=lambda m: ('transcript' not in m.name.lower(), m.source))[0]
    return sub.unique_named(role)
