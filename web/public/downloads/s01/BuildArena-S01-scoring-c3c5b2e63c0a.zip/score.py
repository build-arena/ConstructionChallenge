"""Single command for the fixed S01 validation, scoring and results page."""
import argparse
from pathlib import Path
from scorer.pipeline import ROOT, run

# Historical orbit-center reproduction with your own complete input/evidence:
#   python score.py --input MY_INPUTS --profile corrected
#   python score.py --input MY_INPUTS --profile legacy
# The frozen orbit centers are [0,-600,0] and [0,1200,14], respectively.
# Results are separated into results/corrected/ and results/legacy/.
# Use --rebuild-source PATH_TO_OFFICIAL_S01_V2_0_1 if reconstruction evidence
# must be generated first. Legacy output is diagnostic, not the final ranking.


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, default=ROOT/'raw_submissions', help='Original submission directory')
    parser.add_argument('--rebuild-source', type=Path, help='Recreate reconstruction evidence using the pinned official S01 v2.0.1 source')
    parser.add_argument('--verify', action='store_true', help='Verify the saved result instead of rerunning trajectories')
    parser.add_argument('--profile', choices=('corrected', 'legacy'), default='corrected',
                        help='Frozen scoring configuration (default: corrected)')
    parser.add_argument('--output-dir', type=Path, help='Result directory; defaults to results/<profile>')
    args = parser.parse_args()
    result_path = (args.output_dir or ROOT/'results'/args.profile)/'result.json'
    if args.verify:
        from scorer.verify import verify
        verify(args.input, result_path, profile=args.profile)
    else:
        if args.rebuild_source:
            from scorer.replay import rebuild
            rebuild(args.input, args.rebuild_source)
        result = run(args.input, result_path, profile=args.profile)
        print(result['summary'])
        from scorer.verify import verify
        verify(args.input, result_path, profile=args.profile)


if __name__ == '__main__':
    main()
