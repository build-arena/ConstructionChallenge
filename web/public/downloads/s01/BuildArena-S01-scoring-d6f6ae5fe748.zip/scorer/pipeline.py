"""One fixed pipeline: verify evidence, extract metrics, rank, render."""
import csv
import hashlib
import json
from collections import Counter
from pathlib import Path

from .artifacts import resolve_artifact
from .compliance import audit_submission, compare_structure, package_hash
from .evidence import Submission, ScoreIssue, read_bsg
from .metrics import extract_metrics
from .scoring import rank_two_stage, score_pool, allocate_awards, machine_cost, validate_cost

ROOT = Path(__file__).resolve().parents[1]
RULES = ROOT / 'rules'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def config_directory(profile='corrected'):
    if profile not in {'corrected', 'center-only', 'legacy'}:
        raise ValueError('Unknown scoring profile: '+profile)
    return RULES / profile if profile != 'corrected' else RULES


def load_config(profile='corrected'):
    directory = config_directory(profile)
    cfg = read_json(directory / 'config_s01.json')
    expected = (directory / 'config.sha256').read_text().strip()
    if digest(directory / 'config_s01.json') != expected:
        raise ValueError('固定评分配置已改动；请恢复已确认版本，不能用未冻结参数评分。')
    validate_cost(cfg['cost'])
    return cfg


def check_reconstruction(cfg):
    release = read_json(RULES / 'release.json')
    rebuilt = read_json(RULES / 'reconstruction.json')
    policy = cfg['review_policy']
    if (release['release_tag'], release['commit']) != (policy['reconstruction_release'], policy['reconstruction_commit']):
        raise ValueError('Reconstruction release is not the pinned S01 release')
    hashes = rebuilt['runtime_source_sha256']
    if not hashes or any(release['source_files_sha256'].get(k) != v for k, v in hashes.items()):
        raise ValueError('Reconstruction source fingerprint mismatch')
    return rebuilt


def blocker(audit, rebuilt, team):
    if audit['compliance_status'] not in {'review', 'accepted'}:
        return audit['compliance_status']
    issues = [x for x in audit['issues'] if not x.startswith('pending_verifier_check:')]
    if issues:
        return ';'.join(issues)
    if audit['checks'].get('raw_tuned_structure') != 'passed':
        return 'raw_tuned_structure_not_passed'
    if audit['external_control_candidates']:
        return 'runtime_control_candidate_needs_review'
    if not team:
        return 'team_name_unavailable'
    if not rebuilt or rebuilt['run_package_sha256'] != audit['run_package_sha256']:
        return 'reconstruction_missing_or_stale'
    artifacts = audit['required_artifacts']
    for attempt in rebuilt['attempts']:
        if attempt['history_sha256'] != artifacts['build_history.json']['sha256']:
            continue
        if any(c['matched'] and c['bsg_sha256'] == artifacts['machine_raw.bsg']['sha256']
               for c in attempt.get('comparisons', [])):
            return ''
    return 'exact_raw_history_reconstruction_not_matched'


def dsq_metrics(path, audit, cfg, team):
    sub = Submission(path)
    candidates = [m for m in sub.members if m.name.lower().endswith('.bsg')]
    if not candidates:
        return None
    issues = [i for i in audit['issues'] if not i.startswith('pending_verifier_check:')]
    reason = ';'.join(issues)
    if any('external_runtime_control' in i for i in issues):
        reason = '使用第一季禁止的外部程序运行控制'
    elif any('non_automation_structural_edits' in i for i in issues):
        reason = 'MCP 历史重建 188 块，实际机器 184 块；后续直接编辑 XML 改动非自动化结构，无法重建'
    r = dict(submission_id=path.name, team_id=team, status='DSQ', reason=reason,
             award_eligible=False, compliance_status=audit['compliance_status'],
             run_package_sha256=audit['run_package_sha256'], final_score=None,
             raw_final_score=None, detected_mode=audit['effective_mode'])
    binding = True
    try:
        candidates = [resolve_artifact(sub, 'machine_tuned.bsg')]
    except ScoreIssue:
        unique = list({m.sha256:m for m in candidates}.values())
        try:
            binding = not all(not compare_structure(unique[0].data, m.data) for m in unique[1:])
        except Exception:
            pass
    points = []
    for m in candidates:
        try:
            blocks, _ = read_bsg(m, cfg)
            points.append(machine_cost(blocks, cfg)[0])
        except ScoreIssue:
            pass
    if points and len(set(points)) == 1:
        r['machine_cost_points'] = points[0]
    metric = extract_metrics(path, cfg, audit['effective_mode'], require_tuned_binding=binding)
    return {**metric, **r, 'metric_status':metric['metric_status'], 'metric_reason':metric['metric_reason']}


def run(input_root=ROOT/'raw_submissions', output=None, *, profile='corrected'):
    cfg = load_config(profile)
    output = Path(output) if output is not None else ROOT/'results'/profile/'result.json'
    input_root = Path(input_root).resolve()
    rebuilt = check_reconstruction(cfg)
    rebuilt_rows = {r['submission_id']:r for r in rebuilt['rows']}
    receipts, rulings = (read_json(RULES/name) for name in ('receipts.json','adjudications.json'))
    teams = {r['directory']:r['team_name'] for r in read_json(input_root/'projects_index.json')}
    with (RULES/'modes.csv').open(encoding='utf-8-sig', newline='') as f:
        modes = {r['submission_id']:r['detected_mode'] for r in csv.DictReader(f)}
    paths = sorted(p for p in input_root.iterdir() if p.is_dir())
    if (set(receipts) | set(rulings)) - {p.name for p in paths}:
        raise ValueError('Review decisions reference missing submissions')
    audits, metrics, excluded, dsq = [], [], [], []
    for i, path in enumerate(paths, 1):
        sid = path.name
        mode = modes.get(sid, 'Copilot')
        audit = audit_submission(Submission(path), mode, receipts.get(sid), rulings.get(sid), review_policy=cfg['review_policy'])
        audits.append(audit)
        reason = blocker(audit, rebuilt_rows.get(sid), teams.get(sid))
        if not reason:
            metric = extract_metrics(path, cfg, audit['effective_mode'])
            if metric['metric_status'] == 'ready':
                receipt = audit.get('verified', {})
                metric.update(compliance_status=audit['compliance_status'], auto_technical_passed=True,
                              team_id=receipt.get('team_id', teams[sid]),
                              competitive_eligible=receipt.get('competitive_eligible'),
                              valid_final_submission_time=receipt.get('valid_final_submission_time', ''),
                              run_package_sha256=audit['run_package_sha256'], review_label='待复核')
                metrics.append(metric)
            else:
                reason = metric['metric_reason']
        if reason:
            excluded.append(dict(submission_id=sid, team_id=teams.get(sid,''), reason=reason, status=audit['compliance_status']))
        if audit['compliance_status'] in {'invalid','disqualified'}:
            row = dsq_metrics(path, audit, cfg, teams.get(sid,''))
            if row:
                dsq.append(row)
        print(f'{i}/{len(paths)} {sid.split("_")[0]}: {reason or "scored"}', flush=True)
    local, ranking = rank_two_stage(metrics, cfg, provisional=True)
    # Missing formal receipts never turn provisional results into final results.
    formal_rows = [r for r in metrics if r['compliance_status'] == 'accepted' and r['competitive_eligible']]
    _, formal = rank_two_stage(formal_rows, cfg)
    best = max((r['mean_angular_speed_rad_s'] for r in ranking if r['gate_passed']), default=0.)
    for i, r in enumerate(dsq):
        if r['metric_status'] == 'ready':
            dsq[i] = score_pool([r], cfg, reference_best=best, diagnostic=True)[0]
    result = dict(config=cfg, audits=audits, team_local=local, ranking=ranking, formal_ranking=formal,
                  awards=allocate_awards(ranking,cfg), formal_awards=allocate_awards(formal,cfg),
                  dsq=dsq, excluded=excluded, summary=dict(submissions=len(paths), scored=len(metrics), teams=len(ranking),
                      zero_teams=sum(r['final_score']==0 for r in ranking), compliance=dict(Counter(r['compliance_status'] for r in audits))),
                  provenance=dict(input_root=str(input_root), prior_full_version='00d1730',
                      scoring_profile=profile,
                      selected_config_sha256=digest(config_directory(profile)/'config_s01.json'),
                      rules={p.name:digest(p) for p in RULES.iterdir() if p.is_file()},
                      code={p.name:digest(p) for p in Path(__file__).parent.glob('*.py')},
                      entrypoint_sha256=digest(ROOT/'score.py')))
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False)+'\n',encoding='utf-8')
    from .page import render
    render(result, output.parent/'index.html')
    return result
