"""Evidence-first S01 gate; a present BSG is never a compliance certificate.

Automated checks are diagnostic. Version-pinned replay, vanilla parameter/mod
review, final-run binding, eligibility, mode and timestamp need a verifier
receipt bound to the exact package. Missing checks remain review, never pass.
"""
import hashlib
import json
import math
import re
import xml.etree.ElementTree as ET
from .evidence import ScoreIssue
from .artifacts import resolve_artifact, reviewed_bindings
REQUIRED = ('machine_raw.bsg', 'machine_tuned.bsg', 'build_history.json', 'build_history_full.json', 'trajectory.csv', 'chat_transcript.md')
GEOMETRY_KEY = re.compile('position|rotation|scale|geometry|endpoint|connector|transform|length|anchor|attachment|parent', re.I)
# S01 permits adding Camera and vanilla Automation blocks. Pin (57) is not
# an Automation block and must not be exempt from the structural comparison.
ALLOWED_ADDITIONS = {'58', '65', '66', '67', '68', '69', '70', '75', '93'}
RECEIPT_CHECKS = ('s01_version_reconstruction', 'vanilla_parameters_and_mods', 'final_run_binding', 'transcript_and_build_mode', 'eligibility_and_team', 'deadline_and_final_timestamp', 'runtime_control', 'scoring_environment')

def package_hash(sub):
    members = sorted(((m.original_name or m.name, m.sha256) for m in sub.members))
    return hashlib.sha256(json.dumps(members, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()

def numeric_equal(a, b, tolerance=0.001):
    try:
        a, b = (float(a), float(b))
        return math.isfinite(a) and math.isfinite(b) and (abs(a - b) <= tolerance)
    except (TypeError, ValueError):
        return a == b

def euler_quaternion(node):
    """Unity Quaternion.Euler applies Z, then X, then Y rotations."""
    x, y, z = [math.radians(math.remainder(float(node.findtext(k)), 360.0)) / 2 for k in ('X', 'Y', 'Z')]
    sx, cx, sy, cy, sz, cz = (math.sin(x), math.cos(x), math.sin(y), math.cos(y), math.sin(z), math.cos(z))
    return (cy * sx * cz + sy * cx * sz, sy * cx * cz - cy * sx * sz, cy * cx * sz - sy * sx * cz, cy * cx * cz + sy * sx * sz)

def xml_equal(a, b):
    if a is None or b is None:
        return a is b
    if a.tag != b.tag or set(a.attrib) != set(b.attrib) or len(a) != len(b):
        return False
    if a.tag == 'Vector3' and a.get('key', '').endswith('rotation') and (a.attrib == b.attrib):
        try:
            qa, qb = (euler_quaternion(a), euler_quaternion(b))
            return all((numeric_equal(x, y) for x, y in zip(qa, qb))) or all((numeric_equal(x, -y) for x, y in zip(qa, qb)))
        except (TypeError, ValueError, OverflowError):
            return False
    if a.tag == 'Rotation' and set(a.attrib) == {'x', 'y', 'z', 'w'}:
        direct = all((numeric_equal(a.get(k), b.get(k)) for k in a.attrib))
        try:
            opposite = all((numeric_equal(a.get(k), -float(b.get(k))) for k in a.attrib))
        except (TypeError, ValueError):
            opposite = False
        if not direct and (not opposite):
            return False
    elif not all((numeric_equal(a.get(k), b.get(k)) for k in a.attrib)):
        return False
    if not numeric_equal((a.text or '').strip(), (b.text or '').strip()):
        return False
    return all((xml_equal(x, y) for x, y in zip(a, b)))

def blocks(data):
    root = ET.fromstring(data)
    nodes = root.findall('Blocks/Block')
    if not nodes:
        raise ValueError('BSG has no Blocks/Block nodes')
    ids = [b.get('guid', '').casefold() for b in nodes]
    if not all(ids) or len(set(ids)) != len(ids):
        raise ValueError('missing or duplicate block GUID')
    for b in nodes:
        for part, keys in (('Position', 'xyz'), ('Rotation', 'xyzw'), ('Scale', 'xyz')):
            node = b.find(f'Transform/{part}')
            if node is None or any((k not in node.attrib or not math.isfinite(float(node.get(k))) for k in keys)):
                raise ValueError('missing or nonfinite block Transform')
        q = b.find('Transform/Rotation')
        if abs(sum((float(q.get(k)) ** 2 for k in 'xyzw')) - 1.0) > 0.001:
            raise ValueError('non-unit rotation quaternion')
    return dict(zip(ids, nodes))

def geometry_data(block):
    default_length = {'1': '2', '41': '2', '63': '3'}.get(block.get('id'))
    return {(e.tag, e.get('key', '')): e for e in block.findall('Data/*') if e.get('key', '') not in {'rotation-speed', 'bmt-rotation-speed', 'bmt-water-rotation-speed'} and (not (default_length is not None and e.tag == 'Integer' and (e.attrib == {'key': 'length'}) and ((e.text or '').strip() == default_length) and (len(e) == 0))) and (not (e.tag == 'String' and e.get('key') == 'bmt-TransformHolder' and (not (e.text or '').strip()) and (len(e) == 0))) and (GEOMETRY_KEY.search(e.get('key', '')) or e.tag in {'Vector3', 'Quaternion'})}

def compare_structure(raw, tuned, *, replay=False, allow_guid_regeneration=False):
    a, b = (blocks(raw), blocks(tuned))
    if allow_guid_regeneration and (not replay):
        from .geometry import unique_guid_mapping
        if unique_guid_mapping(raw, tuned) is not None:
            return []
    from .geometry import fuel_line_geometry_equal, ENDPOINT_KEYS
    changes = []
    if replay:
        if len(a) != len(b):
            return ['replay_block_count_mismatch']
        pairs = list(zip(a.items(), b.values()))
    else:
        for guid in sorted(a.keys() - b.keys()):
            changes.append(f'removed_block:{guid}')
        for guid in sorted(b.keys() - a.keys()):
            if b[guid].get('id') not in ALLOWED_ADDITIONS:
                changes.append(f'prohibited_added_block:{guid}:{b[guid].get('id')}')
        pairs = [(item, b[item[0]]) for item in a.items() if item[0] in b]
    for (guid, before), after in pairs:
        if before.get('id') != after.get('id'):
            changes.append(f'block_type_changed:{guid}')
        connector_equal = fuel_line_geometry_equal(before, after)
        if not connector_equal and (not xml_equal(before.find('Transform'), after.find('Transform'))):
            changes.append(f'transform_changed:{guid}')
        left, right = (geometry_data(before), geometry_data(after))
        for key in sorted(left.keys() | right.keys()):
            if connector_equal and key[1] in ENDPOINT_KEYS:
                continue
            if not xml_equal(left.get(key), right.get(key)):
                changes.append(f'geometry_data_changed:{guid}:{key[1]}')
        for key in sorted((set(before.attrib) | set(after.attrib)) - {'guid', 'id'}):
            if before.get(key) != after.get(key):
                changes.append(f'block_attribute_changed:{guid}:{key}')
        left_extra = [x for x in before if x.tag not in {'Transform', 'Data'}]
        right_extra = [x for x in after if x.tag not in {'Transform', 'Data'}]
        if len(left_extra) != len(right_extra) or not all((xml_equal(x, y) for x, y in zip(left_extra, right_extra))):
            changes.append(f'structural_child_changed:{guid}')
    return changes

def external_control_candidates(sub):
    """Extract review leads, NOT an automatic disqualification classifier."""
    pattern = re.compile('(?:controller|closed.loop|predictive).*(?:keyboard|key(?:board)? (?:input|events)|Observer)|(?:keyboard executor|state.feedback controller|remote input executor)|(?:外部|脚本|程序).*(?:自动按键|闭环控制)', re.I)
    out, seen = ([], set())
    for m in sub.members:
        if not m.name.lower().endswith(('.md', '.txt', '.py', '.cs', '.ps1')):
            continue
        for number, line in enumerate(m.data.decode('utf-8-sig', errors='replace').splitlines(), 1):
            if pattern.search(line) and line.strip() not in seen:
                seen.add(line.strip())
                out.append({'source': m.source, 'sha256': m.sha256, 'line': number, 'quote': line[:2400]})
    return out

def audit_submission(sub, mode, receipt=None, ruling=None, *, review_policy=None):
    policy = review_policy or {}
    if mode not in {'Autopilot', 'Copilot', 'Human Boss', 'HumanBoss', 'Human Boss Challenge'} and policy.get('default_unstated_mode'):
        mode = policy['default_unstated_mode']
    exhibition = mode in {'Human Boss', 'HumanBoss', 'Human Boss Challenge'}
    digest = package_hash(sub)
    out = {'submission_id': sub.path.name, 'run_package_sha256': digest, 'compliance_status': 'review', 'issues': [], 'checks': {}, 'required_artifacts': {}, 'external_control_candidates': external_control_candidates(sub)}
    required = tuple((name for name in REQUIRED if name != 'build_history_full.json' or policy.get('separate_full_history_required', True)))
    out['effective_mode'] = mode
    out['required_artifact_count'] = 3 if exhibition else len(required)
    issues, checks = (out['issues'], out['checks'])
    version_pass = (review_policy or {}).get('version_checks_default_pass') is True
    required_checks = list(RECEIPT_CHECKS)
    if version_pass:
        checks['version_consistency'] = 'passed'
        out['version_check_source'] = review_policy['version_source']
        required_checks[required_checks.index('s01_version_reconstruction')] = 'raw_reconstruction'
        required_checks[required_checks.index('scoring_environment')] = 'non_version_scoring_environment'
    if sub.archive_errors:
        issues.append('submission_archive_or_partial_damage')
        out['archive_errors'] = sub.archive_errors
    if not any((m.name.casefold().endswith('.bsg') for m in sub.members)) and (not sub.archive_errors):
        issues.append('missing_bsg')
        out['compliance_status'] = 'invalid'
    try:
        out['artifact_binding_review'] = reviewed_bindings(sub)
    except ScoreIssue as error:
        issues.append(error.reason)
    members = {}
    if exhibition:
        bsgs = [m for m in sub.members if m.name.casefold().endswith('.bsg')]
        if bsgs:
            out['required_artifacts']['submitted_machine.bsg'] = {'candidates': [{'source': m.source, 'sha256': m.sha256} for m in bsgs]}
    for name in ('trajectory.csv', 'writeup.md') if exhibition else required:
        try:
            member = resolve_artifact(sub, name)
            members[name] = member
            out['required_artifacts'][name] = {'source': member.source, 'sha256': member.sha256, 'submitted_name': member.original_name or member.name, 'name_adapter_used': member.name.casefold() != name.casefold()}
            if not member.data.strip():
                issues.append('empty_required_artifact:' + name)
        except ScoreIssue as e:
            issues.append(e.reason + ':' + name)
            out.setdefault('artifact_resolution_issues', []).append({'role': name, 'reason': e.reason, **e.evidence})
    if 'machine_raw.bsg' in members and 'machine_tuned.bsg' in members:
        try:
            changes = compare_structure(members['machine_raw.bsg'].data, members['machine_tuned.bsg'].data, allow_guid_regeneration=out.get('artifact_binding_review', {}).get('allow_guid_regeneration') is True)
            checks['raw_tuned_structure'] = 'review' if changes else 'passed'
            out['structure_changes'] = changes
            if changes:
                issues.append('raw_tuned_structure_difference')
        except (ValueError, ET.ParseError) as e:
            checks['raw_tuned_structure'] = 'review'
            issues.append('bsg_structure_unparseable:' + str(e))
    from .artifacts import transcript_candidates
    out['transcript_sources'] = [{'source': m.source, 'sha256': m.sha256} for m in transcript_candidates(sub)]
    for name in ('build_history.json', 'build_history_full.json'):
        if name in members:
            try:
                history = json.loads(members[name].data)
                if not isinstance(history, list) or not history or (not all((isinstance(x, dict) and isinstance(x.get('op'), str) and isinstance(x.get('params'), dict) for x in history))):
                    raise ValueError('unsupported history schema')
                checks[name] = 'parsed_not_replayed'
            except (ValueError, UnicodeError) as e:
                issues.append('history_review:' + name + ':' + str(e))
    if exhibition:
        out['compliance_status'] = 'exhibition'
        issues.append('human_boss_not_competitive')
        return out
    elif mode not in {'Autopilot', 'Copilot'}:
        issues.append('mode_unresolved_or_unsupported')
    if policy.get('reject_prohibited_structure') and 'raw_tuned_structure_difference' in issues:
        out['compliance_status'] = 'disqualified'
        checks['raw_tuned_structure'] = 'failed'
        issues.insert(0, 'prohibited_structure_difference')
    elif policy.get('reject_missing_necessary_data') and any((i.startswith(('missing_bsg', 'missing_artifact_role:', 'missing_trajectory_csv:', 'empty_required_artifact:', 'bsg_structure_unparseable:', 'history_review:')) for i in issues)):
        out['compliance_status'] = 'invalid'
    if receipt:
        if receipt.get('run_package_sha256') != digest:
            issues.append('stale_verifier_receipt')
        elif not receipt.get('reviewer') or not receipt.get('evidence_sources'):
            issues.append('verifier_receipt_provenance_missing')
        else:
            for name in required_checks:
                legacy_name = {'raw_reconstruction': 's01_version_reconstruction', 'non_version_scoring_environment': 'scoring_environment'}.get(name, name)
                item = receipt.get('checks', {}).get(name, receipt.get('checks', {}).get(legacy_name, {}))
                checks[name] = item.get('status', 'pending')
                if item.get('status') != 'passed' or not item.get('evidence'):
                    issues.append('pending_verifier_check:' + name)
            if receipt.get('mode') != mode or not receipt.get('team_id') or (not receipt.get('valid_final_submission_time')):
                issues.append('verified_identity_mode_or_time_missing')
            else:
                from datetime import datetime
                try:
                    stamp = datetime.fromisoformat(str(receipt['valid_final_submission_time']).replace('Z', '+00:00'))
                    if stamp.tzinfo is None:
                        raise ValueError('timezone required')
                except ValueError:
                    issues.append('verified_final_timestamp_invalid')
            if receipt.get('competitive_eligible') is not True:
                issues.append('competitive_eligibility_not_verified')
            if out['compliance_status'] == 'review' and (not issues):
                out['compliance_status'] = 'accepted'
                out['verified'] = receipt
    else:
        issues.extend(('pending_verifier_check:' + name for name in required_checks))
    if ruling:
        if ruling.get('run_package_sha256') != digest:
            issues.append('stale_adjudication')
            out['compliance_status'] = 'review'
        elif ruling.get('decision') == 'disqualified' and ruling.get('reason') and ruling.get('evidence'):
            out['compliance_status'] = 'disqualified'
            out['adjudication'] = ruling
            issues.insert(0, ruling['reason'])
    return out
