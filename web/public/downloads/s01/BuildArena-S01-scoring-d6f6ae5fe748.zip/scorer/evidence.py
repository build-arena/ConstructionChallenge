from __future__ import annotations
import csv, hashlib, io, json, math, re, zipfile, fnmatch
from datetime import date
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any
import xml.etree.ElementTree as ET
CANONICAL = {'run_id', 'frame_id', 'block_id', 'time_s', 'x', 'y', 'z', 'destroyed', 'connected_to_start'}

class ScoreIssue(Exception):

    def __init__(self, status, reason, **evidence):
        super().__init__(reason)
        self.status = status
        self.reason = reason
        self.evidence = evidence

@dataclass(frozen=True)
class Member:
    name: str
    source: str
    data: bytes
    original_name: str = ''

    @property
    def sha256(self):
        return hashlib.sha256(self.data).hexdigest()

class Submission:
    """Read loose files and ZIP members; never treat an arbitrary CSV as trajectory."""

    def __init__(self, path):
        self.path = Path(path)
        self.members = []
        self.archive_errors = []
        if self.path.is_file() and self.path.suffix.casefold() == '.zip':
            self._zip(self.path, '')
        elif self.path.is_dir():
            for p in sorted(self.path.rglob('*')):
                if not p.is_file():
                    continue
                rel = p.relative_to(self.path).as_posix()
                if p.suffix.casefold() == '.zip':
                    self._zip(p, rel + '!')
                elif p.suffix.casefold() == '.rar':
                    self._rar(p, rel + '!')
                else:
                    try:
                        self.members.append(Member(PurePosixPath(rel).name, rel, p.read_bytes()))
                    except OSError as e:
                        self.archive_errors.append(f'{rel}: {e}')
        else:
            raise ScoreIssue('invalid', 'submission_path_missing')
        for i, member in enumerate(self.members):
            if member.name.lower().endswith('.bsg') or not member.data.lstrip().startswith(b'<'):
                continue
            try:
                root = ET.fromstring(member.data)
            except ET.ParseError:
                continue
            if root.tag == 'Machine' and root.find('Blocks/Block') is not None:
                name = member.name[:-4] if member.name.lower().endswith('.bsg.txt') else member.name + '.bsg'
                self.members[i] = Member(name, member.source, member.data, member.name)

    def _zip(self, path, prefix, depth=0):
        if depth > 4:
            self.archive_errors.append(f'{prefix}: archive nesting limit exceeded')
            return
        try:
            archive_label = '<nested archive>' if isinstance(path, (bytes, bytearray)) else str(path)
            with zipfile.ZipFile(io.BytesIO(path) if isinstance(path, (bytes, bytearray)) else path) as z:
                bad = z.testzip()
                if bad:
                    self.archive_errors.append(f'{prefix}{archive_label}: corrupt member {bad}')
                    return
                for info in z.infolist():
                    if info.is_dir():
                        continue
                    name = PurePosixPath(info.filename.replace('\\', '/')).name
                    if not name or name.startswith('._') or name == '.DS_Store':
                        continue
                    source = prefix + archive_label + '!' + info.filename
                    try:
                        data = z.read(info)
                        if name.casefold().endswith('.zip'):
                            self._zip(data, source + '!', depth + 1)
                        else:
                            self.members.append(Member(name, source, data))
                    except Exception as e:
                        self.archive_errors.append(f'{source}: {e}')
        except Exception as e:
            self.archive_errors.append(f'{prefix}{path}: {e}')

    def _rar(self, path, prefix):
        """Read regular RAR members in memory; never extract archive paths to disk."""
        try:
            import libarchive
            with libarchive.file_reader(str(path)) as archive:
                for entry in archive:
                    if not entry.isreg:
                        continue
                    member_path = entry.pathname.replace('\\', '/')
                    name = PurePosixPath(member_path).name
                    if not name or name.startswith('._') or name == '.DS_Store':
                        continue
                    source = prefix + member_path
                    data = b''.join(entry.get_blocks())
                    if name.casefold().endswith('.zip'):
                        self._zip(data, source + '!')
                    else:
                        self.members.append(Member(name, source, data))
        except Exception as e:
            self.archive_errors.append(f'{prefix}{path.name}: RAR read failed: {e}')

    def named(self, name):
        return [m for m in self.members if m.name.casefold() == name.casefold()]

    def unique_named(self, name, required=True):
        ms = self.named(name)
        byhash = {m.sha256: m for m in ms}
        if len(byhash) > 1:
            raise ScoreIssue('review', 'ambiguous_file_versions', file=name, sources=[m.source for m in ms])
        if not byhash:
            if required:
                raise ScoreIssue('invalid', 'missing_' + name.replace('.', '_'), file=name)
            return None
        return next(iter(byhash.values()))

    def bsg_candidates(self):
        bs = [m for m in self.members if m.name.casefold().endswith('.bsg')]
        if not bs:
            raise ScoreIssue('invalid', 'missing_bsg')
        unique = {m.sha256: m for m in bs}
        return list(unique.values())

def decode(data):
    return data.decode('utf-8-sig', errors='strict')

def parse_csv(member):
    try:
        text = decode(member.data)
    except UnicodeDecodeError as e:
        raise ScoreIssue('invalid', 'trajectory_unparseable', source=member.source, detail=str(e))
    meta = {}
    body = []
    for line in text.replace('\r\n', '\n').replace('\r', '\n').split('\n'):
        if line.startswith('#'):
            k, sep, v = line[1:].strip().partition(',')
            if sep:
                meta[k.strip().casefold()] = v.strip()
        elif line.strip():
            body.append(line)
    if not body:
        raise ScoreIssue('invalid', 'trajectory_header_only_or_empty', source=member.source)
    try:
        reader = csv.DictReader(io.StringIO('\n'.join(body), newline=''))
        names = [str(h or '').strip().casefold() for h in reader.fieldnames or []]
        headers = set(names)
        if not headers or len(headers) != len(names) or '' in names:
            raise ScoreIssue('invalid', 'trajectory_unparseable', source=member.source, detail='empty_or_duplicate_headers')
        rows = []
        for row in reader:
            if None in row:
                raise ScoreIssue('invalid', 'trajectory_unparseable', source=member.source, detail='extra_columns')
            rows.append({str(k).strip().casefold(): str(v or '').strip() for k, v in row.items()})
    except csv.Error as e:
        raise ScoreIssue('invalid', 'trajectory_unparseable', source=member.source, detail=str(e))
    if not rows:
        raise ScoreIssue('invalid', 'trajectory_header_only_or_empty', source=member.source)
    return (rows, meta)

def read_bsg(member, cfg):
    try:
        root = ET.fromstring(member.data)
    except ET.ParseError as e:
        raise ScoreIssue('review', 'bsg_parse_error', detail=str(e))
    container = root.find('Blocks')
    if container is None:
        raise ScoreIssue('review', 'bsg_missing_blocks')
    blocks = {}
    excluded = {x.casefold() for x in cfg['structure'].get('exclude_injected_block_guids', [])}
    for node in container.findall('Block'):
        guid = (node.get('guid') or '').strip().casefold()
        typ = (node.get('id') or '').strip()
        if not guid:
            raise ScoreIssue('review', 'bsg_block_missing_guid')
        if guid in excluded:
            continue
        if guid in blocks:
            raise ScoreIssue('review', 'bsg_duplicate_block_guid', guid=guid)
        blocks[guid] = {'type_id': typ, 'guid': guid}
    starts = [g for g, b in blocks.items() if b['type_id'] == str(cfg['structure'].get('starting_block_type_id', '0'))]
    if len(starts) != 1:
        raise ScoreIssue('review', 'starting_block_identity_ambiguous', matches=starts)
    return (blocks, starts[0])

def select_trajectory(sub):
    """Prefer the canonical filename; otherwise bind only a unique schema/name-identifiable trajectory artifact."""
    exact = sub.named('trajectory.csv')
    if exact:
        return sub.unique_named('trajectory.csv', required=True)
    legacy = {'sample_index', 'target_guid', 'elapsed_seconds', 'x', 'y', 'z', 'machine_integrity', 'machine_block_count'}
    alias_name = re.compile('trajectory|track|telemetry|orbit', re.I)
    csv_members = [m for m in sub.members if m.name.casefold().endswith('.csv')]
    candidates = []
    named = []
    for member in csv_members:
        if alias_name.search(member.name):
            named.append(member)
        try:
            rows, _ = parse_csv(member)
        except ScoreIssue:
            continue
        headers = set(rows[0]) if rows else set()
        if CANONICAL.issubset(headers) or legacy.issubset(headers) or (CANONICAL - {'destroyed', 'connected_to_start'}).issubset(headers):
            candidates.append(member)
    selected = candidates if candidates else named
    unique = {m.sha256: m for m in selected}
    if len(unique) > 1:
        raise ScoreIssue('review', 'ambiguous_trajectory_candidates', sources=[m.source for m in unique.values()], candidate_count=len(unique))
    if unique:
        return next(iter(unique.values()))
    if named:
        raise ScoreIssue('invalid', 'trajectory_unparseable', sources=[m.source for m in named])
    raise ScoreIssue('invalid', 'missing_trajectory_csv', csv_files=len(csv_members))

def vec(r):
    return (float(r['x']), float(r['y']), float(r['z']))

def altitude(r, scene):
    return math.sqrt(sum(((vec(r)[i] - float(scene['planet_center'][i])) ** 2 for i in range(3)))) - float(scene['planet_radius'])

def orbit_gate(rows, cfg):
    gate = cfg['orbit']
    if gate.get('entry_gate_enabled', True) is False:
        # S01: count from the first recorded sample. Do not inspect any legacy
        # altitude center, radius, threshold or dwell time in this mode.
        return (rows[0]['time_s'] if rows else None, None)
    sc = cfg['scene']
    samples = [(r['time_s'], None if r['destroyed'] or None in (r['x'], r['y'], r['z']) else altitude(r, sc)) for r in rows]
    entry = None
    i = 0
    while i < len(samples):
        if samples[i][1] is not None and samples[i][1] >= gate['entry_altitude']:
            j = i
            while j + 1 < len(samples) and samples[j + 1][1] is not None and (samples[j + 1][1] >= gate['entry_altitude']):
                j += 1
            if samples[j][0] - samples[i][0] + 1e-09 >= gate['entry_duration_s']:
                entry = samples[i][0]
                break
            i = j + 1
        else:
            i += 1
    if entry is None:
        return (None, None)
    exit_at = None
    i = next((k for k, (t, _) in enumerate(samples) if t >= entry), len(samples))
    while i < len(samples):
        if samples[i][1] is not None and samples[i][1] < gate['exit_altitude']:
            j = i
            while j + 1 < len(samples) and samples[j + 1][1] is not None and (samples[j + 1][1] < gate['exit_altitude']):
                j += 1
            if samples[j][0] - samples[i][0] + 1e-09 >= gate['exit_duration_s']:
                exit_at = samples[i][0]
                break
            i = j + 1
        else:
            i += 1
    return (entry, exit_at)

def normals(count):
    golden = math.pi * (3 - math.sqrt(5))
    out = []
    for i in range(count):
        z = (i + 0.5) / count
        r = math.sqrt(max(0.0, 1 - z * z))
        a = i * golden
        out.append((r * math.cos(a), r * math.sin(a), z))
    return out + [(1.0, 0.0, 0.0), (0.0, 1.0, 0.0), (0.0, 0.0, 1.0)]

def plane_angle(points, center, n, min_radius, max_segment):
    seed = (1.0, 0.0, 0.0) if abs(n[0]) < 0.9 else (0.0, 1.0, 0.0)
    c = (n[1] * seed[2] - n[2] * seed[1], n[2] * seed[0] - n[0] * seed[2], n[0] * seed[1] - n[1] * seed[0])
    mag = math.sqrt(sum((x * x for x in c)))
    u = tuple((x / mag for x in c))
    v = (n[1] * u[2] - n[2] * u[1], n[2] * u[0] - n[0] * u[2], n[0] * u[1] - n[1] * u[0])
    angles = []
    for p in points:
        d = tuple((p[k] - center[k] for k in range(3)))
        a = sum((d[k] * u[k] for k in range(3)))
        b = sum((d[k] * v[k] for k in range(3)))
        if math.hypot(a, b) < min_radius:
            return None
        angles.append(math.atan2(b, a))
    total = 0.0
    for a, b in zip(angles, angles[1:]):
        d = math.atan2(math.sin(b - a), math.cos(b - a))
        if abs(d) > max_segment:
            return None
        total += d
    return abs(total)

def _content(value):
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        return '\n'.join((x if isinstance(x, str) else x.get('text', '') for x in value if isinstance(x, str) or (isinstance(x, dict) and (x.get('type') in {'text', 'input_text', 'output_text'} or x.get('kind') == 'text'))))
    if isinstance(value, dict):
        return _content(value.get('parts', value.get('text', '')))
    return ''

def _json_messages(obj):
    found = []
    deleted = []

    def omitted(mapping, allowed, reason):
        if isinstance(mapping, dict):
            for key in sorted(set(mapping) - set(allowed), key=str.casefold):
                deleted.append({'reason': reason, 'field': str(key)})
    if isinstance(obj, dict) and isinstance(obj.get('requests'), list):
        omitted(obj, {'requests'}, 'exporter_conversation_metadata')
        for request in obj['requests']:
            if not isinstance(request, dict):
                deleted.append({'reason': 'malformed_chat_export_request'})
                continue
            request_id = str(request.get('requestId', request.get('responseId', '')))
            omitted(request, {'requestId', 'responseId', 'message', 'response'}, 'exporter_request_metadata')
            user = request.get('message', {})
            if isinstance(user, dict):
                omitted(user, {'parts', 'text'}, 'exporter_user_message_metadata')
                body = _content(user.get('parts', user.get('text', '')))
                if body:
                    found.append((request_id + ':user', 'user', body))
            for index, item in enumerate(request.get('response', []) or []):
                if not isinstance(item, dict):
                    deleted.append({'reason': 'malformed_response_component', 'component_index': index})
                    continue
                kind = str(item.get('kind', ' ')).casefold()
                if kind == 'toolinvocationserialized':
                    deleted.append({'reason': 'explicit_tool_invocation_or_return', 'tool_call_id': str(item.get('toolCallId', ''))})
                    continue
                if kind == 'mcpserversstarting':
                    deleted.append({'reason': 'exporter_server_start_metadata'})
                    continue
                if kind == 'thinking':
                    deleted.append({'reason': 'non_user_facing_internal_thinking'})
                    continue
                if isinstance(item.get('value'), str) and {'baseUri', 'supportHtml'}.issubset(item):
                    found.append((str(item.get('id', request_id + ':response:' + str(index))), 'assistant', item['value']))
                    omitted(item, {'value', 'id', 'baseUri', 'supportHtml'}, 'exporter_response_metadata')
                    for key in ('baseUri', 'supportHtml'):
                        deleted.append({'reason': 'exporter_response_metadata', 'field': key})
                elif item.get('value') not in (None, ''):
                    deleted.append({'reason': 'unrecognized_chat_export_component', 'component_index': index})
                else:
                    omitted(item, {'kind', 'id'}, 'exporter_response_metadata')
        return (found, deleted)

    def walk(x):
        if isinstance(x, dict):
            msg = x.get('message')
            if isinstance(msg, dict):
                author = msg.get('author', {})
                nested_role = str(author.get('role', msg.get('role', ''))).casefold()
                body = _content(msg.get('content', msg.get('text', '')))
                if nested_role in {'system', 'developer', 'user', 'human', 'assistant'}:
                    if body:
                        found.append((str(x.get('id', msg.get('id', ''))), nested_role, body))
                    omitted(msg, {'author', 'role', 'content', 'text', 'id'}, 'exporter_message_metadata')
                    if isinstance(author, dict) and 'role' in author:
                        deleted.append({'reason': 'exporter_role_label', 'field': 'author.role'})
                    for key in ('timestamp', 'created_at', 'updated_at', 'sent_at'):
                        if key in msg:
                            deleted.append({'reason': 'exporter_timestamp', 'field': 'message.' + key})
                    return
                if nested_role in {'tool', 'function'}:
                    deleted.append({'reason': 'explicit_tool_message', 'role': nested_role})
                    return
            role = str(x.get('role', x.get('speaker', ''))).casefold()
            if role in {'tool', 'function'}:
                deleted.append({'reason': 'explicit_tool_message', 'role': role})
                return
            if role in {'system', 'developer', 'user', 'human', 'assistant'}:
                text = _content(x.get('content', x.get('text', '')))
                if text:
                    found.append((str(x.get('id', x.get('message_id', ''))), role, text))
                omitted(x, {'role', 'speaker', 'content', 'text', 'id', 'message_id'}, 'exporter_message_metadata')
                if 'role' in x:
                    deleted.append({'reason': 'exporter_role_label', 'field': 'role'})
                elif 'speaker' in x:
                    deleted.append({'reason': 'exporter_role_label', 'field': 'speaker'})
                for key in ('timestamp', 'created_at', 'updated_at', 'sent_at'):
                    if key in x:
                        deleted.append({'reason': 'exporter_timestamp', 'field': key})
                for k in ('tool_calls', 'function_call', 'tool_call', 'tool_result', 'function_results'):
                    if x.get(k) not in (None, [], {}):
                        deleted.append({'reason': 'explicit_tool_payload', 'key': k})
                return
            for k, v in x.items():
                if k.casefold() in {'tool_calls', 'function_call', 'tool_call', 'tool_result', 'function_results'}:
                    if v not in (None, [], {}):
                        deleted.append({'reason': 'explicit_tool_payload', 'key': k})
                else:
                    walk(v)
        elif isinstance(x, list):
            for v in x:
                walk(v)
    walk(obj)
    return (found, deleted)
ROLE = re.compile('^\\s*(?:#{1,6}\\s*)?(system|developer|user|human|assistant|tool(?:\\s+(?:call|return|result|output))?|function(?:\\s+(?:call|return|result|output))?)\\s*:?\\s*$', re.I)
STAMP = re.compile('^\\s*\\[?(\\d{4}-\\d\\d-\\d\\d[T ]\\d\\d:\\d\\d(?::\\d\\d(?:\\.\\d+)?)?(?:Z|[+-]\\d\\d:\\d\\d)?)\\]?\\s+(system|developer|user|human|assistant|tool(?:\\s+(?:call|return|result|output))?|function(?:\\s+(?:call|return|result|output))?)\\s*:?\\s*(.*)$', re.I)

def _md_messages(text):
    text = text.replace('\r\n', '\n').replace('\r', '\n')
    out = []
    deleted = []
    role = None
    tool = False
    buf = []

    def flush():
        nonlocal buf
        value = '\n'.join(buf)
        if value and tool:
            deleted.append({'reason': 'explicit_tool_section', 'chars': len(value)})
        elif value and role:
            out.append(('', role, value))
        buf = []
    for line in text.split('\n'):
        m = STAMP.match(line)
        if m:
            flush()
            role = m.group(2).casefold()
            tool = role.startswith('tool') or role.startswith('function')
            deleted.append({'reason': 'exporter_timestamp_and_role_label', 'line': line[:120]})
            if m.group(3):
                buf.append(m.group(3))
            continue
        m = ROLE.match(line)
        if m:
            flush()
            role = m.group(1).casefold()
            tool = role.startswith('tool') or role.startswith('function')
            deleted.append({'reason': 'role_label', 'line': line[:120]})
            continue
        if re.match('^\\s*(?:exported|generated|timestamp|created_at)\\s*[:=]', line, re.I):
            deleted.append({'reason': 'exporter_timestamp', 'line': line[:120]})
            continue
        line = re.sub('(?<!\\w)\\[\\d{4}-\\d\\d-\\d\\d[T ]\\d\\d:\\d\\d(?::\\d\\d(?:\\.\\d+)?)?(?:Z|[+-]\\d\\d:\\d\\d)?\\](?!\\w)', '', line)
        buf.append(line)
    flush()
    if not out:
        clean = [l for l in text.split('\n') if not re.match('^\\s*(?:exported|generated|timestamp|created_at)\\s*[:=]', l, re.I)]
        value = '\n'.join(clean)
        if value.strip('\n'):
            out = [('', 'user', value)]
    return (out, deleted)

def clean_tokens(sub, cfg):
    excluded = {x.casefold() for x in cfg['token']['exclude_names']}
    globs = [x.casefold() for x in cfg['token'].get('exclude_globs', [])]
    exts = {x.casefold() for x in cfg['token']['extensions']}
    from .artifacts import is_dialogue_text, reviewed_bindings
    reviewed_transcript_hash = reviewed_bindings(sub).get('roles', {}).get('chat_transcript.md')
    all_text_files = [m for m in sub.members if PurePosixPath(m.name).suffix.casefold() in exts or m.name.casefold() == '.md']
    interaction_name = re.compile('(?:chat|conversation|conversacion|transcript|prompt|workflow|session|build[_ -]?(?:log|process)|system[_ -]?prompt|agents\\.md)', re.I)
    files = []
    for m in all_text_files:
        name = m.name.casefold()
        ext = PurePosixPath(m.name).suffix.casefold()
        if name in excluded or any((fnmatch.fnmatchcase(name, g) for g in globs)) or name.startswith('invalid_no_bsg') or re.search('(^|[_ -])(?:kaggle[_ -]?)?writeup(?:[_. -]|$)', m.name, re.I):
            continue
        if ext == '.json' or interaction_name.search(name) or is_dialogue_text(m.data) or (m.sha256 == reviewed_transcript_hash):
            files.append(m)
    if not files:
        raise ScoreIssue('review', 'chat_or_prompt_evidence_missing')
    chunks = []
    deleted = [{'source': m.source, 'reason': 'submission_writeup_not_build_interaction_log' if re.search('(^|[_ -])(?:kaggle[_ -]?)?writeup(?:[_. -]|$)', m.name, re.I) else 'excluded_by_configured_source_rule' if m.name.casefold() in excluded or any((fnmatch.fnmatchcase(m.name.casefold(), g) for g in globs)) else 'non_interaction_document_by_source_rule'} for m in all_text_files if m not in files]
    hashes = {}
    ids = {}
    try:
        session_parsed, session_duplicates = session_export_adapters(files)
    except ValueError as error:
        raise ScoreIssue('review', 'session_export_schema_unsupported', detail=str(error))
    dialogue_exports = {}
    for m in sorted(files, key=lambda x: (x.name.casefold(), x.source.casefold())):
        if m.sha256 in hashes:
            deleted.append({'source': m.source, 'reason': 'duplicate_export_file_exact_sha256', 'duplicate_of': hashes[m.sha256]})
            continue
        hashes[m.sha256] = m.source
        if m.sha256 in session_duplicates:
            deleted.append({'source': m.source, **session_duplicates[m.sha256]})
            continue
        try:
            text = decode(m.data)
        except UnicodeDecodeError as e:
            raise ScoreIssue('review', 'text_evidence_decode_error', source=m.source, detail=str(e))
        if is_dialogue_text(m.data):
            export_key = re.sub('\\s+', '', text)
            if export_key in dialogue_exports:
                deleted.append({'source': m.source, 'reason': 'duplicate_dialogue_export_whitespace_only', 'duplicate_of': dialogue_exports[export_key]})
                continue
            dialogue_exports[export_key] = m.source
        if PurePosixPath(m.name).suffix.casefold() == '.json':
            try:
                obj = json.loads(text)
            except json.JSONDecodeError as e:
                repaired = text.replace('"[REDACTED_CREDENTIAL]""', '"[REDACTED_CREDENTIAL]"')
                if repaired == text:
                    raise ScoreIssue('review', 'conversation_json_parse_error', source=m.source, detail=str(e))
                try:
                    obj = json.loads(repaired)
                except json.JSONDecodeError:
                    raise ScoreIssue('review', 'conversation_json_parse_error', source=m.source, detail=str(e))
                deleted.append({'source': m.source, 'reason': 'redacted_credential_duplicate_quote_adapter'})
            messages, removed = session_parsed[m.sha256] if m.sha256 in session_parsed else _json_messages(obj)
            deleted.extend(({'source': m.source, **x} for x in removed))
            explicit_vscode_export = isinstance(obj, dict) and isinstance(obj.get('requests'), list)
            if messages and (not interaction_name.search(m.name)) and (not explicit_vscode_export):
                raise ScoreIssue('review', 'json_message_schema_source_ambiguous', source=m.source, message_count=len(messages))
            if not messages:
                if re.search('chat|conversation|transcript|session|message', m.name, re.I):
                    raise ScoreIssue('review', 'conversation_json_no_supported_messages', source=m.source)
                if re.search('prompt|workflow|system', m.name, re.I):
                    messages = [('', 'system', json.dumps(obj, ensure_ascii=False, separators=(',', ':')))]
                else:
                    deleted.append({'source': m.source, 'reason': 'unrecognized_structured_json_not_interaction_log'})
                    continue
            for mid, role, body in messages:
                digest = hashlib.sha256(body.encode()).hexdigest()
                if mid and mid in ids:
                    if ids[mid] != digest:
                        raise ScoreIssue('review', 'duplicate_message_id_content_conflict', message_id=mid)
                    deleted.append({'source': m.source, 'reason': 'duplicate_logical_message_id', 'message_id': mid})
                    continue
                if mid:
                    ids[mid] = digest
                chunks.append(body)
        else:
            messages, removed = _md_messages(text)
            deleted.extend(({'source': m.source, **x} for x in removed))
            chunks.extend((body for _, _, body in messages))
    cleaned = '\n\n'.join((x.replace('\r\n', '\n').replace('\r', '\n') for x in chunks))
    if not cleaned.strip():
        raise ScoreIssue('review', 'chat_or_prompt_evidence_empty')
    try:
        import tiktoken
        if getattr(tiktoken, '__version__', None) != cfg['token']['tiktoken_version']:
            raise ScoreIssue('review', 'tiktoken_version_mismatch', expected=cfg['token']['tiktoken_version'], actual=getattr(tiktoken, '__version__', None))
        count = len(tiktoken.get_encoding(cfg['token']['encoding']).encode_ordinary(cleaned))
    except ScoreIssue:
        raise
    except Exception as e:
        raise ScoreIssue('review', 'tiktoken_unavailable', detail=str(e))
    return (cleaned, count, deleted, hashes)
from collections import Counter
import json
import re

def session_messages(obj):
    """Return (messages, removal_log), or None for another exporter schema."""
    if not (isinstance(obj, dict) and isinstance(obj.get('session'), dict) and isinstance(obj['session'].get('id'), str) and isinstance(obj.get('messages'), list) and all((isinstance(m, dict) and isinstance(m.get('parts'), list) for m in obj['messages']))):
        return None
    found, removed = ([], [])
    session_id = obj['session']['id']
    for index, message in enumerate(obj['messages']):
        role = message.get('role', '').lower()
        if role in {'tool', 'function'}:
            removed.append({'reason': 'explicit_tool_message', 'message_index': index})
            continue
        if role not in {'user', 'assistant', 'system', 'developer', 'human'}:
            raise ValueError('unsupported session message role')
        parts = []
        for part in message['parts']:
            kind = part.get('type') if isinstance(part, dict) else None
            if kind in {'text', 'input_text', 'output_text'}:
                if not isinstance(part.get('text'), str):
                    raise ValueError('session text part without text')
                parts.append(part['text'])
            elif kind in {'tool', 'function', 'reasoning', 'step-start', 'step-finish', 'timeline', 'file'}:
                removed.append({'reason': 'session_non_dialogue_part', 'part_type': kind, 'message_index': index, 'part_id': part.get('id', '')})
            else:
                raise ValueError('unsupported session part type: ' + str(kind))
        body = '\n'.join(parts)
        if body:
            mid = message.get('id') or f'{session_id}:message:{index}'
            found.append((str(mid), role, body))
    user_bodies = Counter((body for _, role, body in found if role in {'user', 'human'}))
    for index, prompt in enumerate(obj.get('user_inputs', [])):
        if not isinstance(prompt, dict) or not isinstance(prompt.get('text'), str):
            raise ValueError('unsupported session user_inputs schema')
        body = prompt['text']
        if user_bodies[body]:
            user_bodies[body] -= 1
            removed.append({'reason': 'duplicate_user_input_index', 'prompt_index': index})
        elif body:
            found.append((f'{session_id}:user-input:{index}', 'user', body))
    return (found, removed)

def _normalize(text):
    return re.sub('\\s+', '', text)

def _visible_markdown(text, session_id):
    text = text.replace('\r\r\n', '\n').replace('\r\n', '\n').replace('\r', '\n')
    if not re.search('(?m)^(?:- session id: |)`' + re.escape(session_id) + '`', text):
        return None
    if text.startswith('# 会话可见对话'):
        marker = re.search('(?m)^## (?:用户|助手)\\s*$', text)
        if not marker:
            return None
        body = text[marker.start():]
        return re.sub('(?m)^## (?:用户|助手)\\s*$', '', body)
    if text.startswith('# 会话导出：'):
        marker = re.search('(?m)^## Turn \\d+ · 用户 · ', text)
        if not marker:
            return None
        body = text[marker.start():]
        body = re.sub('<details><summary>工具调用 \\d+ 次</summary>.*?</details>', '', body, flags=re.S)
        body = re.sub('(?m)^---\\s*\\n(?=## Turn )', '', body)
        return re.sub('(?m)^## Turn \\d+ · 用户 · .*?$|^### 助手 · .*?$', '', body)
    return None

def session_export_adapters(members):
    """Return JSON parse overrides and proven duplicate MD exports by SHA256.

    Call before clean_tokens' per-file loop. For a parsed hash use its tuple
    instead of _json_messages; retain the scorer's logical-message-ID conflict
    and duplicate checks. For a duplicate MD hash append its removal record
    and skip that file. Nonmatching Markdown is never discarded.
    """
    parsed, duplicate_md, sessions = ({}, {}, [])
    for member in members:
        if not member.name.lower().endswith('.json'):
            continue
        try:
            obj = json.loads(member.data)
        except (ValueError, UnicodeError):
            continue
        result = session_messages(obj)
        if result is not None:
            parsed[member.sha256] = result
            sessions.append((obj['session']['id'], member, result[0]))
    for member in members:
        if not member.name.lower().endswith('.md'):
            continue
        try:
            text = member.data.decode('utf-8-sig')
        except UnicodeError:
            continue
        for session_id, original, messages in sessions:
            visible = _visible_markdown(text, session_id)
            if visible is not None and _normalize(visible) == _normalize(''.join((body for _, _, body in messages))):
                duplicate_md[member.sha256] = {'reason': 'duplicate_session_markdown_verified_visible_text', 'session_id': session_id, 'duplicate_of': original.source, 'duplicate_of_sha256': original.sha256}
                break
    return (parsed, duplicate_md)
