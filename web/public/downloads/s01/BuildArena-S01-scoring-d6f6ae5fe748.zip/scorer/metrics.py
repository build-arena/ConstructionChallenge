"""Extract fixed S01 metrics from the original submitted machine and run."""
from __future__ import annotations
import hashlib
import json
import math
import re
from collections import Counter
from pathlib import Path
from .evidence import ScoreIssue, Submission, clean_tokens, normals, orbit_gate, parse_csv, plane_angle, read_bsg, select_trajectory
METHOD_VERSION = 'S01-fixed-v1'
HEALTH_SOURCE = 'Sum(Modding.Blocks.Block.Health) / Sum(Modding.Blocks.Block.MaxHealth) over PlayerMachine.SimulationBlocks'

def extract_metrics(path: Path, cfg: dict, mode: str, *, require_tuned_binding=True) -> dict:
    """Internal numeric extraction; not eligibility certification or a final rank."""
    out = dict(submission_id=path.name, score_version=cfg.get('score_version', METHOD_VERSION), metric_status='unavailable', metric_reason='not_scored', detected_mode=mode, evidence={})
    try:
        sub = Submission(path)
        out['evidence'] = {'archive_errors': sub.archive_errors[:20]}
        if sub.archive_errors:
            raise ScoreIssue('review', 'submission_archive_or_partial_damage')
        if cfg['cost'].get('error_weight', 0):
            from .scoring import error_metrics
            out.update(error_metrics(sub))
            out['evidence']['error_cost'] = {k: out[k] for k in ('failed_operation_count', 'full_history_operation_count', 'failed_operation_ratio', 'error_history_source', 'error_history_sha256', 'error_cost_basis')}
        candidates = sub.bsg_candidates()
        if require_tuned_binding:
            from .artifacts import resolve_artifact
            candidates = [resolve_artifact(sub, 'machine_tuned.bsg')]
        out['evidence']['bsg_candidates'] = [{'source': m.source, 'sha256': m.sha256} for m in candidates]
        trajectory = resolve_artifact(sub, 'trajectory.csv') if require_tuned_binding else select_trajectory(sub)
        raw, meta = parse_csv(trajectory)
        out['evidence'].update({'trajectory_source': trajectory.source, 'trajectory_sha256': trajectory.sha256})
        required = {'sample_index', 'target_guid', 'elapsed_seconds', 'machine_integrity', 'machine_block_count', 'x', 'y', 'z'}
        if not raw or not required.issubset(raw[0]):
            raise ScoreIssue('review', 'legacy_proxy_schema_incomplete', missing=sorted(required - set(raw[0] if raw else {})))
        if meta.get('tracker_enabled', '').casefold() != 'true' or meta.get('machine_integrity_source') != HEALTH_SOURCE:
            raise ScoreIssue('review', 'health_proxy_provenance_unverified')
        interval = meta.get('sample_interval_seconds')
        if interval:
            interval_s = float(interval)
        else:
            hz = float(meta.get('sample_rate_hz', '0'))
            if hz <= 0:
                raise ScoreIssue('review', 'sample_interval_not_declared')
            interval_s = 1.0 / hz
        expected = 1.0 / float(cfg['trajectory']['reference_sample_rate_hz'])
        tolerance = float(cfg['trajectory']['time_tolerance_s'])
        if interval_s <= 0 or abs(interval_s - expected) > tolerance:
            raise ScoreIssue('review', 'sample_interval_config_mismatch')
        target_ids = {r['target_guid'].strip().casefold() for r in raw}
        if len(target_ids) != 1 or not next(iter(target_ids)):
            raise ScoreIssue('review', 'legacy_target_not_unique')
        root_guid = next(iter(target_ids))
        roots = []
        sample_indices = set()
        previous = None
        for r in raw:
            try:
                sample_index = int(r['sample_index'])
                t = float(r['elapsed_seconds'])
                xyz = tuple((float(r[k]) for k in ('x', 'y', 'z')))
                health = float(r['machine_integrity'])
                block_count = int(float(r['machine_block_count']))
            except (TypeError, ValueError, OverflowError):
                raise ScoreIssue('review', 'legacy_tracker_value_invalid')
            if sample_index in sample_indices or not all((math.isfinite(x) for x in (*xyz, t, health))):
                raise ScoreIssue('review', 'legacy_tracker_duplicate_or_nonfinite')
            if not 0 <= health <= 1 or block_count <= 0:
                raise ScoreIssue('review', 'legacy_tracker_health_or_count_out_of_range')
            sample_indices.add(sample_index)
            row = {'frame_id': sample_index, 'time_s': t, 'x': xyz[0], 'y': xyz[1], 'z': xyz[2], 'destroyed': False}
            if previous is not None:
                dt = t - previous['time_s']
                di = sample_index - previous['frame_id']
                if dt <= 0 or di <= 0 or di - 1 > int(cfg['orbit']['max_interpolated_frames']):
                    raise ScoreIssue('review', 'legacy_tracker_time_or_gap_invalid')
                max_frames = int(cfg['orbit']['max_interpolated_frames']) + 1
                if dt > max_frames * interval_s + tolerance:
                    raise ScoreIssue('review', 'legacy_sample_time_gap_exceeds_budget', dt_s=dt, index_gap=di)
                speed = math.dist(xyz, (previous['x'], previous['y'], previous['z'])) / dt
                if speed > float(cfg['trajectory']['max_trusted_speed']):
                    raise ScoreIssue('review', 'untrusted_position_jump', speed=speed)
            row['machine_integrity'] = health
            row['machine_block_count'] = block_count
            roots.append(row)
            previous = row
        cap = float(cfg['performance']['max_flight_time_s'])
        if roots[0]['time_s'] > 0.05:
            raise ScoreIssue('review', 'starting_observation_not_at_launch', first_sample_s=roots[0]['time_s'])
        initial_count = roots[0]['machine_block_count']
        bsg_matches = []
        for member in candidates:
            blocks, start = read_bsg(member, cfg)
            if start == root_guid and (len(blocks) == initial_count or cfg.get('review_policy', {}).get('tracker_block_count_is_not_gate')):
                bsg_matches.append({'source': member.source, 'sha256': member.sha256, 'block_count': len(blocks)})
        if not bsg_matches:
            raise ScoreIssue('review', 'tracker_start_or_block_count_not_bound_to_bsg')
        out['evidence']['score_relevant_bsg_matches'] = bsg_matches
        from .scoring import machine_cost
        point_totals = []
        for match in bsg_matches:
            member = next((m for m in candidates if m.sha256 == match['sha256']))
            point_blocks, _ = read_bsg(member, cfg)
            points, detail = machine_cost(point_blocks, cfg)
            point_totals.append(points)
            match['machine_cost_points'] = points
            match['block_points_evidence'] = detail
        if len(set(point_totals)) != 1:
            raise ScoreIssue('review', 'machine_cost_ambiguous_between_bsg_variants')
        out['machine_cost_points'] = point_totals[0]
        out['evidence']['block_count_comparison'] = {'tracker_initial_count': initial_count, 'selected_bsg_counts': [m['block_count'] for m in bsg_matches], 'count_difference_is_gate': not cfg.get('review_policy', {}).get('tracker_block_count_is_not_gate', False), 'cost_count_source': 'selected_bsg' if cfg.get('review_policy', {}).get('tracker_block_count_is_not_gate') else 'tracker_initial_count', 'extra_block_identities': 'not recorded in aggregate Tracker CSV'}
        try:
            clean_text, token_count, deletions, token_hashes = clean_tokens(sub, cfg)
        except ScoreIssue as e:
            raise ScoreIssue('review', 'token_evidence_unavailable', underlying_reason=e.reason)
        out['cleaned_token_count'] = token_count
        out['evidence']['token_cleaning'] = dict(cleaned_text_sha256=hashlib.sha256(clean_text.encode()).hexdigest(), removed_records=len(deletions), methods=dict(Counter((d.get('reason', '') for d in deletions))))
        out['evidence'].update({'token_source_sha256': token_hashes, 'time_cap_s': cap, 'sample_interval_s': interval_s, 'user_endpoint_policy': 'last recorded sample before time cap is treated as run end; no unobserved continuation is inferred'})
        if mode not in cfg['mode_coefficients']:
            raise ScoreIssue('review', 'mode_unresolved_or_unsupported', mode=mode)
        before = [r for r in roots if r['time_s'] <= cap]
        after = [r for r in roots if r['time_s'] >= cap]
        if not before:
            raise ScoreIssue('review', 'no_observation_at_or_before_time_cap')
        last_before = before[-1]
        if roots[-1]['time_s'] < cap:
            score_end = roots[-1]['time_s']
            cap_rows = list(roots)
            terminal_basis = 'submission_log_end_treated_as_terminal'
            terminal_reason = 'ok_user_authorized_log_end_terminal'
        elif abs(last_before['time_s'] - cap) <= tolerance:
            score_end = cap
            cap_rows = list(before)
            terminal_basis = '900s_time_cap_observed_in_trajectory'
            terminal_reason = 'ok_observed_to_shared_time_cap'
        else:
            if not after:
                raise ScoreIssue('review', 'time_cap_not_bracketed')
            right = after[0]
            span = right['time_s'] - last_before['time_s']
            max_span = (int(cfg['orbit']['max_interpolated_frames']) + 1) * interval_s + tolerance
            if span <= 0 or span > max_span or right['frame_id'] - last_before['frame_id'] != 1:
                raise ScoreIssue('review', 'time_cap_interpolation_gap_invalid')
            alpha = (cap - last_before['time_s']) / span
            cap_rows = list(before) + [{**last_before, 'time_s': cap, 'x': last_before['x'] + alpha * (right['x'] - last_before['x']), 'y': last_before['y'] + alpha * (right['y'] - last_before['y']), 'z': last_before['z'] + alpha * (right['z'] - last_before['z']), 'frame_id': right['frame_id']}]
            score_end = cap
            terminal_basis = '900s_time_cap_interpolated_from_adjacent_samples'
            terminal_reason = 'ok_observed_to_shared_time_cap'
        entry, exit_at = orbit_gate(cap_rows, cfg)
        stop_on_exit = cfg['orbit'].get('stop_on_exit', True)
        terminal_t = min(score_end, exit_at) if stop_on_exit and exit_at is not None else score_end
        window_policy = ('recording start through recording end or time cap; no altitude gate'
                         if cfg['orbit'].get('entry_gate_enabled', True) is False else
                         'first entry through recording end or time cap; exit is diagnostic only'
                         if not stop_on_exit else 'first entry through first confirmed exit or run end')
        out['evidence']['orbit_window'] = {'stop_on_exit': stop_on_exit, 'entry_time_s': entry, 'first_exit_time_s_diagnostic': exit_at, 'score_end_time_s': terminal_t, 'policy': window_policy}
        active = [r for r in cap_rows if entry is not None and entry <= r['time_s'] <= terminal_t]
        angle = 0.0
        if entry is not None:
            if len(active) < 2:
                raise ScoreIssue('review', 'orbit_samples_insufficient')
            results = [plane_angle([(r['x'], r['y'], r['z']) for r in active], cfg['scene']['orbit_center'], n, float(cfg['orbit']['min_radius']), float(cfg['orbit']['max_segment_angle_rad'])) for n in normals(int(cfg['orbit']['candidate_plane_count']))]
            results = [v for v in results if v is not None]
            if not results:
                raise ScoreIssue('review', 'all_candidate_planes_degenerate_or_aliased')
            angle = max(results)
        valid_time = max(0.0, terminal_t - roots[0]['time_s'])
        progress = min(1.0, angle / (2 * math.pi * float(cfg['performance']['target_full_laps'])))
        omega = angle / valid_time if valid_time > 0 and entry is not None else 0.0
        health_row = max((r for r in roots if r['time_s'] <= terminal_t), key=lambda r: r['time_s'])
        if terminal_t - health_row['time_s'] > interval_s + tolerance:
            next_health = next((r for r in roots if r['time_s'] >= terminal_t), None)
            stable_bracket = next_health is not None and next_health['frame_id'] - health_row['frame_id'] == 1 and (next_health['time_s'] - health_row['time_s'] <= (int(cfg['orbit']['max_interpolated_frames']) + 1) * interval_s + tolerance) and (next_health['machine_integrity'] == health_row['machine_integrity']) and (next_health['machine_block_count'] == health_row['machine_block_count'])
            if not stable_bracket:
                raise ScoreIssue('review', 'terminal_health_proxy_sample_too_far', terminal_time_s=terminal_t, sample_time_s=health_row['time_s'])
        integrity_proxy = health_row['machine_integrity']
        end_source = raw[min(len(raw) - 1, roots.index(health_row))]
        try:
            clusters = int(float(end_source.get('machine_cluster_count', '')))
        except (TypeError, ValueError):
            clusters = ''
        physical_blocks = bsg_matches[0]['block_count'] if cfg.get('review_policy', {}).get('tracker_block_count_is_not_gate') else initial_count
        out.update(gate_passed=entry is not None, structure_integrity=integrity_proxy, block_count=physical_blocks)
        out.update({'metric_status': 'ready', 'metric_reason': terminal_reason, 'detected_mode': mode, 'terminal_basis': terminal_basis, 'valid_time_s': valid_time, 'observed_through_s': roots[-1]['time_s'], 'orbit_entry_time_s': '' if entry is None else entry, 'orbit_exit_time_s': '' if exit_at is None else exit_at, 'angular_displacement_rad': angle, 'orbit_progress': progress, 'mean_angular_speed_rad_s': omega, 'structure_integrity_proxy': integrity_proxy, 'integrity_proxy_definition': 'tracker machine_integrity = total health / total max health; NOT exact live-and-connected block fraction', 'integrity_proxy_sample_time_s': health_row['time_s'], 'machine_cluster_count': clusters, 'physical_block_count': physical_blocks, 'evidence': {**out['evidence'], 'health_source': meta['machine_integrity_source'], 'health_proxy_value': integrity_proxy, 'health_proxy_sample_time_s': health_row['time_s'], 'machine_cluster_count': clusters, 'initial_machine_block_count': initial_count, 'time_cap_interpolated_from_s': [last_before['time_s'], right['time_s']] if terminal_basis == '900s_time_cap_interpolated_from_adjacent_samples' else None, 'per_block_states_missing': True, 'score_is_provisional_proxy': True}})
    except ScoreIssue as e:
        out['metric_status'] = 'invalid' if e.status == 'invalid' else 'review'
        out['metric_reason'] = e.reason
        out['evidence'] = {**out.get('evidence', {}), **e.evidence}
    except Exception as e:
        out['metric_status'] = 'review'
        out['metric_reason'] = 'unexpected_proxy_scoring_error'
        out['evidence'] = {**out.get('evidence', {}), 'error_type': type(e).__name__, 'detail': str(e)}
    return out
